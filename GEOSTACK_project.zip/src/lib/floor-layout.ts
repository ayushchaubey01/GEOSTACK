/**
 * floor-layout.ts
 *
 * Single source of truth for 3D floor geometry:
 * - Shared dimensions between tower floors and extracted/solo floor views
 * - Wall positions, sizes, door openings, and window openings
 * - Correct unit centres including central core offset (CORE_W / 2 + GAP + UNIT_W / 2)
 */

export interface WallBox {
  position: [number, number, number]; // [x, y, z] center of box
  size: [number, number, number];     // [width, height, depth]
  kind: 'unit' | 'core' | 'partition' | 'lintel' | 'sill';
  side?: 'north' | 'south' | 'east' | 'west' | 'inner';
}

export const FLOOR_DIMENSIONS = {
  width: 20.0,
  depth: 16.0,
  height: 3.0,
  slabThickness: 0.22,
  wallHeight: 2.78, // 3.0 - 0.22
  wallThickness: 0.14,
  coreWidth: 4.0,
  coreDepth: 4.0,
  unitWidth: 6.5,
  unitDepth: 5.0,
  corridorGap: 0.8,
  doorWidth: 0.9,
  doorHeight: 2.1,
  windowWidth: 1.6,
  windowHeight: 1.3,
  windowSillHeight: 0.85,
} as const;

const {
  width: W,
  depth: D,
  wallHeight: H,
  wallThickness: T,
  coreWidth: CW,
  coreDepth: CD,
  unitWidth: UW,
  unitDepth: UD,
  corridorGap: GAP,
  doorWidth: DW,
  doorHeight: DH,
  windowWidth: WW,
  windowHeight: WH,
  windowSillHeight: WS,
} = FLOOR_DIMENSIONS;

// Correct unit centres: ±(CW/2 + GAP + UW/2), ±(CD/2 + GAP + UD/2)
export const UNIT_CENTERS = [
  { id: 'NE', idx: 0, x: +(CW / 2 + GAP + UW / 2), z: -(CD / 2 + GAP + UD / 2), facing: 'North' as const },
  { id: 'NW', idx: 1, x: -(CW / 2 + GAP + UW / 2), z: -(CD / 2 + GAP + UD / 2), facing: 'North' as const },
  { id: 'SW', idx: 2, x: -(CW / 2 + GAP + UW / 2), z: +(CD / 2 + GAP + UD / 2), facing: 'South' as const },
  { id: 'SE', idx: 3, x: +(CW / 2 + GAP + UW / 2), z: +(CD / 2 + GAP + UD / 2), facing: 'South' as const },
] as const;

/**
 * Returns all wall bounding boxes for a single floor layout.
 * Y is centered around H / 2 (where y=0 is top of slab).
 */
export function getFloorWallBoxes(): WallBox[] {
  const boxes: WallBox[] = [];
  const yMid = H / 2;

  // ── 1. Central Core Walls (4 walls around elevator & stairs) ─────────────
  boxes.push(
    // North core wall
    { position: [0, yMid, -CD / 2], size: [CW, H, T], kind: 'core', side: 'inner' },
    // South core wall
    { position: [0, yMid, CD / 2], size: [CW, H, T], kind: 'core', side: 'inner' },
    // East core wall
    { position: [CW / 2, yMid, 0], size: [T, H, CD], kind: 'core', side: 'inner' },
    // West core wall
    { position: [-CW / 2, yMid, 0], size: [T, H, CD], kind: 'core', side: 'inner' },
  );

  // ── 2. Units (4 apartments) ──────────────────────────────────────────────
  for (const uc of UNIT_CENTERS) {
    const isNorth = uc.z < 0;
    const isEast = uc.x > 0;

    // Outer perimeter walls on North / South side (with window opening)
    const outerZ = isNorth ? uc.z - UD / 2 : uc.z + UD / 2;
    const sideNS = isNorth ? 'north' : 'south';
    const sideFlankLen = (UW - WW) / 2;

    // Flank left
    boxes.push({
      position: [uc.x - (UW / 2 - sideFlankLen / 2), yMid, outerZ],
      size: [sideFlankLen, H, T],
      kind: 'unit',
      side: sideNS,
    });
    // Flank right
    boxes.push({
      position: [uc.x + (UW / 2 - sideFlankLen / 2), yMid, outerZ],
      size: [sideFlankLen, H, T],
      kind: 'unit',
      side: sideNS,
    });
    // Window sill
    boxes.push({
      position: [uc.x, WS / 2, outerZ],
      size: [WW, WS, T],
      kind: 'sill',
      side: sideNS,
    });
    // Window lintel
    const lintelH = H - (WS + WH);
    boxes.push({
      position: [uc.x, WS + WH + lintelH / 2, outerZ],
      size: [WW, lintelH, T],
      kind: 'lintel',
      side: sideNS,
    });

    // Outer perimeter walls on East / West side
    const outerX = isEast ? uc.x + UW / 2 : uc.x - UW / 2;
    const sideEW = isEast ? 'east' : 'west';
    boxes.push({
      position: [outerX, yMid, uc.z],
      size: [T, H, UD],
      kind: 'unit',
      side: sideEW,
    });

    // Corridor-facing entry wall (facing core along Z) with door opening
    const innerZ = isNorth ? uc.z + UD / 2 : uc.z - UD / 2;
    const entryFlankLen = (UW - DW) / 2;
    boxes.push({
      position: [uc.x - (UW / 2 - entryFlankLen / 2), yMid, innerZ],
      size: [entryFlankLen, H, T],
      kind: 'unit',
      side: 'inner',
    });
    boxes.push({
      position: [uc.x + (UW / 2 - entryFlankLen / 2), yMid, innerZ],
      size: [entryFlankLen, H, T],
      kind: 'unit',
      side: 'inner',
    });
    // Lintel above door
    const doorLintelH = H - DH;
    boxes.push({
      position: [uc.x, DH + doorLintelH / 2, innerZ],
      size: [DW, doorLintelH, T],
      kind: 'lintel',
      side: 'inner',
    });

    // Inner corridor wall facing core along X
    const innerX = isEast ? uc.x - UW / 2 : uc.x + UW / 2;
    boxes.push({
      position: [innerX, yMid, uc.z],
      size: [T, H, UD],
      kind: 'unit',
      side: 'inner',
    });

    // Interior room partition (separates living room & bedroom)
    const partitionFlank = (UD - DW) / 2;
    boxes.push({
      position: [uc.x, yMid, uc.z - (UD / 2 - partitionFlank / 2)],
      size: [UW * 0.45, H, T],
      kind: 'partition',
      side: 'inner',
    });
  }

  return boxes;
}
