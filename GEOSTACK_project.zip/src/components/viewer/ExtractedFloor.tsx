'use client';

/**
 * ExtractedFloor.tsx
 *
 * Detailed floor plate view (extracted & solo inspect):
 * - Dimensions match building floors (20m x 16m)
 * - Interior & perimeter walls rendered via FloorInterior with view-dependent cutaway
 * - Correct unit centres: ±(CORE_W/2 + GAP + UNIT_W/2)
 * - Light floor tiles (#F3F4F6, hover #EEF2FF, selected #E0E7FF)
 * - Unit labels (drei Html) displayed in solo inspect mode
 * - Clean token palette (Indigo / Slate) — zero rogue colors
 */

import { useEffect, useMemo, useRef, useState } from 'react';
import { ThreeEvent } from '@react-three/fiber';
import { Html } from '@react-three/drei';
import * as THREE from 'three';
import { useViewerStore, useBuilding } from '@/lib/viewer-store';
import { registerRef } from './useTransitionController';
import {
  matSlabEdge,
  matSoffit,
  matRailing,
  matBalconyTile,
  matXraySlab,
  matUnitFloorPlane,
  matUnitFloorHover,
  matUnitFloorSelected,
} from '@/lib/viewer-materials';
import { FloorInterior } from './FloorInterior';
import { FLOOR_DIMENSIONS, UNIT_CENTERS } from '@/lib/floor-layout';
import { COLOR_PRIMARY_600, COLOR_PRIMARY_500 } from '@/lib/design-tokens';
import type { Unit } from '@/lib/building-data';

const {
  width: FLOOR_W,
  depth: FLOOR_D,
  slabThickness: SLAB_T,
  unitWidth: UNIT_W,
  unitDepth: UD,
  coreWidth: CORE_W,
  coreDepth: CORE_D,
  wallHeight: WALL_H,
} = FLOOR_DIMENSIONS;

export default function ExtractedFloor() {
  const groupRef = useRef<THREE.Group>(null);
  const selectedFloor = useViewerStore((s) => s.selectedFloor);
  const phase = useViewerStore((s) => s.phase);
  const xrayMode = useViewerStore((s) => s.xrayMode);
  const setPhase = useViewerStore((s) => s.setPhase);
  const building = useBuilding();

  const activeFloorNumber = selectedFloor ?? 0;
  const floor = useMemo(
    () => building.floors.find((f) => f.floorNumber === activeFloorNumber) ?? building.floors[0],
    [building, activeFloorNumber],
  );

  useEffect(() => {
    if (!groupRef.current) return;
    registerRef('extractedFloor', groupRef.current);

    const shouldShow = selectedFloor !== null && phase !== 'overview' && phase !== 'loading' && phase !== 'returning';
    groupRef.current.visible = shouldShow;
  }, [phase, selectedFloor]);

  const onFloorClick = (e: ThreeEvent<MouseEvent>) => {
    e.stopPropagation();
    if (phase !== 'extracted') return;
    setPhase('floor_inspect_selecting');
  };

  return (
    <group ref={groupRef} position={[24, 8, 0]} scale={0.6}>
      {/* Floor plate (clickable to enter solo inspect) */}
      <group onClick={onFloorClick}>
        <FloorPlate width={FLOOR_W} depth={FLOOR_D} xrayMode={xrayMode} />
        <CentralCore xrayMode={xrayMode} />
        <ConnectorLine fromX={-11} toX={0} y={0} />
      </group>

      {/* Interior & perimeter walls with directional cutaway */}
      <group position={[0, 0, 0]}>
        <FloorInterior
          mode="floor_view"
          xrayMode={xrayMode}
          cutawayActive={phase === 'extracted' || phase === 'floor_inspecting'}
        />
      </group>

      {/* Interactive Units (floor tiles, balconies, and solo labels) */}
      {floor.units.map((u, i) => (
        <UnitInteractive
          key={u.unitId}
          unit={u}
          center={UNIT_CENTERS[i]}
          phase={phase}
          xrayMode={xrayMode}
        />
      ))}
    </group>
  );
}

/* ------------------------------------------------------------------ */
/* Floor plate slab & perimeter curb                                  */
/* ------------------------------------------------------------------ */

function FloorPlate({ width, depth, xrayMode }: { width: number; depth: number; xrayMode: boolean }) {
  return (
    <group>
      <mesh position={[0, -SLAB_T / 2, 0]} material={xrayMode ? matXraySlab : matSlabEdge}>
        <boxGeometry args={[width, SLAB_T, depth]} />
      </mesh>
      {!xrayMode && (
        <mesh position={[0, -SLAB_T - 0.02, 0]} material={matSoffit}>
          <boxGeometry args={[width + 0.05, 0.04, depth + 0.05]} />
        </mesh>
      )}
    </group>
  );
}

/* ------------------------------------------------------------------ */
/* Central core (elevator & stair opening)                            */
/* ------------------------------------------------------------------ */

function CentralCore({ xrayMode }: { xrayMode: boolean }) {
  return (
    <group position={[0, 0.01, 0]}>
      {/* Inner shaft opening */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.005, 0]}>
        <planeGeometry args={[CORE_W - 0.4, CORE_D - 0.4]} />
        <meshBasicMaterial color={xrayMode ? '#EEF2FF' : '#E5E7EB'} />
      </mesh>
    </group>
  );
}

/* ------------------------------------------------------------------ */
/* Interactive Unit                                                   */
/* ------------------------------------------------------------------ */

interface UnitInteractiveProps {
  unit: Unit;
  center: typeof UNIT_CENTERS[number];
  phase: string;
  xrayMode: boolean;
}

function UnitInteractive({ unit, center, phase, xrayMode }: UnitInteractiveProps) {
  const [hovered, setHovered] = useState(false);
  const selectedUnitId = useViewerStore((s) => s.selectedUnitId);
  const selectUnit = useViewerStore((s) => s.selectUnit);
  const hoverUnit = useViewerStore((s) => s.hoverUnit);

  const isSelected = selectedUnitId === unit.unitId;

  const onPointerOver = (e: ThreeEvent<PointerEvent>) => {
    e.stopPropagation();
    setHovered(true);
    hoverUnit(unit.unitId);
  };

  const onPointerOut = (e: ThreeEvent<PointerEvent>) => {
    e.stopPropagation();
    setHovered(false);
    hoverUnit(null);
  };

  const onClick = (e: ThreeEvent<MouseEvent>) => {
    e.stopPropagation();
    selectUnit(isSelected ? null : unit.unitId);
  };

  // Balcony placement on outer facade & label offset
  const isNorth = center.z < 0;
  const isEast = center.x > 0;
  const balconyZ = isNorth ? -UD / 2 - 0.45 : UD / 2 + 0.45;

  return (
    <group position={[center.x, 0, center.z]}>
      {/* Floor tile plane (pickable) */}
      <mesh
        rotation={[-Math.PI / 2, 0, 0]}
        position={[0, 0.015, 0]}
        onPointerOver={onPointerOver}
        onPointerOut={onPointerOut}
        onClick={onClick}
        material={
          isSelected
            ? matUnitFloorSelected
            : hovered
            ? matUnitFloorHover
            : matUnitFloorPlane
        }
      >
        <planeGeometry args={[UNIT_W - 0.1, UD - 0.1]} />
      </mesh>

      {/* Exterior Unit Balcony */}
      {!xrayMode && (
        <group position={[0, 0, balconyZ]}>
          <mesh position={[0, 0.04, 0]} material={matBalconyTile}>
            <boxGeometry args={[UNIT_W * 0.7, 0.08, 0.9]} />
          </mesh>
          <mesh position={[0, 0.5, isNorth ? -0.42 : 0.42]} material={matRailing}>
            <boxGeometry args={[UNIT_W * 0.7, 0.9, 0.04]} />
          </mesh>
        </group>
      )}

      {/* Unit label in solo inspect mode (HTML pill) */}
      {phase === 'floor_inspecting' && (
        <Html position={[isEast ? 1.4 : -1.4, WALL_H + 0.45, isNorth ? -1.0 : 1.0]} center distanceFactor={14}>
          <div
            className={`px-3 py-1 rounded-full text-xs font-semibold tracking-tight border shadow-xs select-none pointer-events-none whitespace-nowrap transition-colors ${
              isSelected
                ? 'bg-[#4F46E5] text-white border-[#4338CA]'
                : hovered
                ? 'bg-[#EEF2FF] text-[#4F46E5] border-[#C7D2FE]'
                : 'bg-white/95 text-[#0F172A] border-[#E5E7EB]'
            }`}
          >
            {unit.displayId ? `Flat ${unit.displayId}` : unit.unitId}
          </div>
        </Html>
      )}
    </group>
  );
}

/* ------------------------------------------------------------------ */
/* Connector Line (dashed indicator between tower and extracted floor)*/
/* ------------------------------------------------------------------ */

function ConnectorLine({ fromX, toX, y }: { fromX: number; toX: number; y: number }) {
  const totalLen = Math.abs(toX - fromX);
  const segs = 14;
  const segLen = totalLen / (segs * 2);

  return (
    <group position={[0, y, 0]}>
      {Array.from({ length: segs }, (_, i) => {
        const t = (i + 0.5) / segs;
        const x = fromX + t * totalLen;
        return (
          <mesh key={i} position={[x, 0, 0]}>
            <boxGeometry args={[segLen, 0.04, 0.04]} />
            <meshBasicMaterial color={new THREE.Color(COLOR_PRIMARY_500)} transparent opacity={0.65} />
          </mesh>
        );
      })}
    </group>
  );
}
