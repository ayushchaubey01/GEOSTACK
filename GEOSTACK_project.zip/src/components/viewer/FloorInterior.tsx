'use client';

/**
 * FloorInterior.tsx
 *
 * Efficient interior wall rendering using module-scope merged BufferGeometries:
 * - 2 draw calls per floor in tower X-ray (1 mesh + 1 lineSegments)
 * - View-dependent cutaway in floor view (extracted/solo)
 * - Zero geometry or material allocations per frame
 */

import React, { useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { mergeGeometries } from 'three/examples/jsm/utils/BufferGeometryUtils.js';
import { getFloorWallBoxes, WallBox } from '@/lib/floor-layout';
import {
  matWallXrayDefault,
  matWallXrayHover,
  matWallXraySelected,
  matWallFloorNormal,
  matWallFloorXray,
  matWallFloorEdges,
} from '@/lib/viewer-materials';

function buildMergedBoxes(boxes: WallBox[]): THREE.BufferGeometry {
  if (boxes.length === 0) return new THREE.BufferGeometry();
  const geos: THREE.BufferGeometry[] = [];
  for (const b of boxes) {
    const g = new THREE.BoxGeometry(b.size[0], b.size[1], b.size[2]);
    g.translate(b.position[0], b.position[1], b.position[2]);
    geos.push(g);
  }
  const merged = mergeGeometries(geos, false);
  for (const g of geos) g.dispose();
  return merged;
}

// ── Module-scope merged geometries ──────────────────────────────────────────
const allBoxes = getFloorWallBoxes();

export const TOWER_WALLS_GEO = buildMergedBoxes(allBoxes);
export const TOWER_WALLS_EDGES = new THREE.EdgesGeometry(TOWER_WALLS_GEO);

const innerBoxes = allBoxes.filter((b) => b.side === 'inner' || b.kind === 'core');
const northBoxes = allBoxes.filter((b) => b.side === 'north');
const southBoxes = allBoxes.filter((b) => b.side === 'south');
const eastBoxes = allBoxes.filter((b) => b.side === 'east');
const westBoxes = allBoxes.filter((b) => b.side === 'west');

export const INNER_WALLS_GEO = buildMergedBoxes(innerBoxes);
export const INNER_WALLS_EDGES = new THREE.EdgesGeometry(INNER_WALLS_GEO);

export const NORTH_WALLS_GEO = buildMergedBoxes(northBoxes);
export const SOUTH_WALLS_GEO = buildMergedBoxes(southBoxes);
export const EAST_WALLS_GEO = buildMergedBoxes(eastBoxes);
export const WEST_WALLS_GEO = buildMergedBoxes(westBoxes);

export const NORTH_WALLS_EDGES = new THREE.EdgesGeometry(NORTH_WALLS_GEO);
export const SOUTH_WALLS_EDGES = new THREE.EdgesGeometry(SOUTH_WALLS_GEO);
export const EAST_WALLS_EDGES = new THREE.EdgesGeometry(EAST_WALLS_GEO);
export const WEST_WALLS_EDGES = new THREE.EdgesGeometry(WEST_WALLS_GEO);

// ── Shared directional cutaway materials ───────────────────────────────────
function makePerimeterMaterial(initialOpacity = 1.0) {
  return new THREE.MeshStandardMaterial({
    color: new THREE.Color('#F9FAFB'),
    roughness: 0.85,
    metalness: 0.02,
    transparent: true,
    opacity: initialOpacity,
    side: THREE.DoubleSide,
  });
}

const matNorth = makePerimeterMaterial();
const matSouth = makePerimeterMaterial();
const matEast = makePerimeterMaterial();
const matWest = makePerimeterMaterial();

interface FloorInteriorProps {
  mode: 'tower_xray' | 'floor_view';
  isHovered?: boolean;
  isSelected?: boolean;
  xrayMode?: boolean;
  cutawayActive?: boolean;
}

export function FloorInterior({
  mode,
  isHovered = false,
  isSelected = false,
  xrayMode = false,
  cutawayActive = false,
}: FloorInteriorProps) {
  const groupRef = useRef<THREE.Group>(null);
  const worldCamPos = useRef(new THREE.Vector3());
  const localCamPos = useRef(new THREE.Vector3());

  // View-dependent cutaway in floor view (extracted or solo)
  useFrame(({ camera }) => {
    if (!cutawayActive || mode !== 'floor_view' || !groupRef.current) return;

    camera.getWorldPosition(worldCamPos.current);
    localCamPos.current.copy(worldCamPos.current);
    groupRef.current.worldToLocal(localCamPos.current);

    const cx = localCamPos.current.x;
    const cz = localCamPos.current.z;

    // Fade walls that face towards the camera so interior remains visible
    const targetNorth = cz < -1 ? 0.20 : 0.95;
    const targetSouth = cz > 1 ? 0.20 : 0.95;
    const targetEast = cx > 1 ? 0.20 : 0.95;
    const targetWest = cx < -1 ? 0.20 : 0.95;

    // Smooth damping
    matNorth.opacity += (targetNorth - matNorth.opacity) * 0.1;
    matSouth.opacity += (targetSouth - matSouth.opacity) * 0.1;
    matEast.opacity += (targetEast - matEast.opacity) * 0.1;
    matWest.opacity += (targetWest - matWest.opacity) * 0.1;
  });

  // ── Tower X-ray Mode: 2 draw calls per floor ─────────────────────────────
  if (mode === 'tower_xray') {
    const wallMat = isSelected
      ? matWallXraySelected
      : isHovered
      ? matWallXrayHover
      : matWallXrayDefault;

    return (
      <group ref={groupRef}>
        <mesh geometry={TOWER_WALLS_GEO} material={wallMat} />
        <lineSegments geometry={TOWER_WALLS_EDGES} material={matWallFloorEdges} />
      </group>
    );
  }

  // ── Floor View Mode (Extracted / Solo) ───────────────────────────────────
  // In X-ray mode: uniform blueprint transparency for all walls
  if (xrayMode) {
    return (
      <group ref={groupRef}>
        <mesh geometry={TOWER_WALLS_GEO} material={matWallFloorXray} />
        <lineSegments geometry={TOWER_WALLS_EDGES} material={matWallFloorEdges} />
      </group>
    );
  }

  // In normal mode: inner walls solid + perimeter walls with directional cutaway
  return (
    <group ref={groupRef}>
      {/* Inner walls (central core + partitions + corridor) */}
      <mesh geometry={INNER_WALLS_GEO} material={matWallFloorNormal} />
      <lineSegments geometry={INNER_WALLS_EDGES} material={matWallFloorEdges} />

      {/* Perimeter walls with view-dependent cutaway */}
      {cutawayActive ? (
        <>
          <mesh geometry={NORTH_WALLS_GEO} material={matNorth} />
          <lineSegments geometry={NORTH_WALLS_EDGES} material={matWallFloorEdges} />

          <mesh geometry={SOUTH_WALLS_GEO} material={matSouth} />
          <lineSegments geometry={SOUTH_WALLS_EDGES} material={matWallFloorEdges} />

          <mesh geometry={EAST_WALLS_GEO} material={matEast} />
          <lineSegments geometry={EAST_WALLS_EDGES} material={matWallFloorEdges} />

          <mesh geometry={WEST_WALLS_GEO} material={matWest} />
          <lineSegments geometry={WEST_WALLS_EDGES} material={matWallFloorEdges} />
        </>
      ) : (
        <>
          <mesh geometry={NORTH_WALLS_GEO} material={matWallFloorNormal} />
          <lineSegments geometry={NORTH_WALLS_EDGES} material={matWallFloorEdges} />

          <mesh geometry={SOUTH_WALLS_GEO} material={matWallFloorNormal} />
          <lineSegments geometry={SOUTH_WALLS_EDGES} material={matWallFloorEdges} />

          <mesh geometry={EAST_WALLS_GEO} material={matWallFloorNormal} />
          <lineSegments geometry={EAST_WALLS_EDGES} material={matWallFloorEdges} />

          <mesh geometry={WEST_WALLS_GEO} material={matWallFloorNormal} />
          <lineSegments geometry={WEST_WALLS_EDGES} material={matWallFloorEdges} />
        </>
      )}
    </group>
  );
}
export default FloorInterior;
