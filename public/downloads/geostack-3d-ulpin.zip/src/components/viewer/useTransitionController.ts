'use client';

/**
 * useTransitionController
 *
 * Drives a 2-step floor inspection flow:
 *
 *   overview
 *     ↓ click floor
 *   floor_selecting → extracted (floor on RIGHT, building on LEFT)
 *     ↓ click extracted floor
 *   floor_inspect_selecting → floor_inspecting (solo centered, building hidden)
 *     ↓ back button
 *   floor_inspect_returning → extracted
 *     ↓ back button (from extracted)
 *   returning → overview
 *
 * All animations are frame-synced via R3F's useFrame — no GSAP.
 */

import { useEffect, useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { useViewerStore, ViewPhase } from '@/lib/viewer-store';

interface RegisteredRefs {
  building?: THREE.Group | null;
  extractedFloor?: THREE.Group | null;
  camera?: THREE.PerspectiveCamera | null;
  controls?: any;
}

const refs: RegisteredRefs = {};

export function registerRef(key: keyof RegisteredRefs, value: any) {
  (refs as any)[key] = value;
}

/* ------------------------------------------------------------------ */
/* Phase target values                                                 */
/* ------------------------------------------------------------------ */

// Overview camera: pulled back so the entire building is visible
const OVERVIEW_POS = new THREE.Vector3(55, 32, 55);
const OVERVIEW_TARGET = new THREE.Vector3(0, 18, 0);

// Extracted camera: building on left + extracted floor on right (pulled back)
const EXTRACTED_POS = new THREE.Vector3(42, 26, 56);
const EXTRACTED_TARGET = new THREE.Vector3(0, 12, 0);

// Solo inspect camera: floor centered, pulled back to see full floor
const SOLO_POS = new THREE.Vector3(20, 15, 24);
const SOLO_TARGET = new THREE.Vector3(0, 3, 0);

const BUILDING_X_OVERVIEW = 0;
const BUILDING_X_EXTRACTED = -12; // shifted left in extracted view

const FLOOR_X_HIDDEN = 24; // off-screen right initially
const FLOOR_X_EXTRACTED = 13; // right side in extracted view
const FLOOR_X_SOLO = 0; // centered in solo inspect view

const FLOOR_SCALE_HIDDEN = 0.6;
const FLOOR_SCALE_EXTRACTED = 1.3;
const FLOOR_SCALE_SOLO = 2.0;

/* ------------------------------------------------------------------ */
/* Transition state                                                    */
/* ------------------------------------------------------------------ */

interface Channel { cur: number; tgt: number; }

interface TransitionState {
  buildingX: Channel;
  buildingOpacity: Channel; // 1 = visible, 0 = hidden (solo inspect)
  cameraPos: { cur: THREE.Vector3; tgt: THREE.Vector3 };
  cameraTarget: { cur: THREE.Vector3; tgt: THREE.Vector3 };
  floorX: Channel;
  floorScale: Channel;
  floorOpacity: Channel;
}

const state: TransitionState = {
  buildingX: { cur: 0, tgt: 0 },
  buildingOpacity: { cur: 1, tgt: 1 },
  cameraPos: { cur: OVERVIEW_POS.clone(), tgt: OVERVIEW_POS.clone() },
  cameraTarget: { cur: OVERVIEW_TARGET.clone(), tgt: OVERVIEW_TARGET.clone() },
  floorX: { cur: FLOOR_X_HIDDEN, tgt: FLOOR_X_HIDDEN },
  floorScale: { cur: FLOOR_SCALE_HIDDEN, tgt: FLOOR_SCALE_HIDDEN },
  floorOpacity: { cur: 0, tgt: 0 },
};

const LERP = 0.085;

// Phase durations (ms) before flipping to the "settled" phase
const PHASE_DURATIONS: Record<string, number> = {
  floor_selecting: 1100,
  floor_inspect_selecting: 900,
  floor_inspect_returning: 800,
  returning: 900,
};

let transitionStart = 0;
let pendingFinalPhase: ViewPhase | null = null;

export function runTransition(targetPhase: ViewPhase) {
  transitionStart = performance.now();

  switch (targetPhase) {
    case 'floor_selecting':
      // Step 1: building shifts left + extracted floor slides in from right
      state.buildingX.tgt = BUILDING_X_EXTRACTED;
      state.buildingOpacity.tgt = 1;
      state.cameraPos.tgt.copy(EXTRACTED_POS);
      state.cameraTarget.tgt.copy(EXTRACTED_TARGET);
      state.floorX.tgt = FLOOR_X_EXTRACTED;
      state.floorScale.tgt = FLOOR_SCALE_EXTRACTED;
      state.floorOpacity.tgt = 1;
      pendingFinalPhase = 'extracted';
      break;

    case 'extracted':
      state.buildingX.tgt = BUILDING_X_EXTRACTED;
      state.buildingOpacity.tgt = 1;
      state.cameraPos.tgt.copy(EXTRACTED_POS);
      state.cameraTarget.tgt.copy(EXTRACTED_TARGET);
      state.floorX.tgt = FLOOR_X_EXTRACTED;
      state.floorScale.tgt = FLOOR_SCALE_EXTRACTED;
      state.floorOpacity.tgt = 1;
      pendingFinalPhase = null;
      break;

    case 'floor_inspect_selecting':
      // Step 2: building fades out, extracted floor moves to center + scales up
      state.buildingX.tgt = BUILDING_X_OVERVIEW;
      state.buildingOpacity.tgt = 0;
      state.cameraPos.tgt.copy(SOLO_POS);
      state.cameraTarget.tgt.copy(SOLO_TARGET);
      state.floorX.tgt = FLOOR_X_SOLO;
      state.floorScale.tgt = FLOOR_SCALE_SOLO;
      state.floorOpacity.tgt = 1;
      pendingFinalPhase = 'floor_inspecting';
      break;

    case 'floor_inspecting':
      state.buildingOpacity.tgt = 0;
      state.cameraPos.tgt.copy(SOLO_POS);
      state.cameraTarget.tgt.copy(SOLO_TARGET);
      state.floorX.tgt = FLOOR_X_SOLO;
      state.floorScale.tgt = FLOOR_SCALE_SOLO;
      state.floorOpacity.tgt = 1;
      pendingFinalPhase = null;
      break;

    case 'floor_inspect_returning':
      // From solo back to extracted view
      state.buildingX.tgt = BUILDING_X_EXTRACTED;
      state.buildingOpacity.tgt = 1;
      state.cameraPos.tgt.copy(EXTRACTED_POS);
      state.cameraTarget.tgt.copy(EXTRACTED_TARGET);
      state.floorX.tgt = FLOOR_X_EXTRACTED;
      state.floorScale.tgt = FLOOR_SCALE_EXTRACTED;
      state.floorOpacity.tgt = 1;
      pendingFinalPhase = 'extracted';
      break;

    case 'returning':
      // From extracted back to overview
      state.buildingX.tgt = BUILDING_X_OVERVIEW;
      state.buildingOpacity.tgt = 1;
      state.cameraPos.tgt.copy(OVERVIEW_POS);
      state.cameraTarget.tgt.copy(OVERVIEW_TARGET);
      state.floorX.tgt = FLOOR_X_HIDDEN;
      state.floorScale.tgt = FLOOR_SCALE_HIDDEN;
      state.floorOpacity.tgt = 0;
      pendingFinalPhase = 'overview';
      break;

    case 'overview':
      state.buildingX.tgt = BUILDING_X_OVERVIEW;
      state.buildingOpacity.tgt = 1;
      state.cameraPos.tgt.copy(OVERVIEW_POS);
      state.cameraTarget.tgt.copy(OVERVIEW_TARGET);
      state.floorX.tgt = FLOOR_X_HIDDEN;
      state.floorScale.tgt = FLOOR_SCALE_HIDDEN;
      state.floorOpacity.tgt = 0;
      pendingFinalPhase = null;
      break;
  }
}

/* ------------------------------------------------------------------ */
/* The hook                                                            */
/* ------------------------------------------------------------------ */

export function useTransitionController() {
  const phase = useViewerStore((s) => s.phase);
  const selectedFloor = useViewerStore((s) => s.selectedFloor);
  const lastPhase = useRef<ViewPhase>(phase);
  const lastFloor = useRef<number | null>(selectedFloor);

  useEffect(() => {
    // Re-trigger transition when EITHER phase changes OR the selected
    // floor changes (so direct floor-to-floor switching works even
    // when the phase stays the same e.g. floor_selecting → floor_selecting)
    const phaseChanged = phase !== lastPhase.current;
    const floorChanged = selectedFloor !== lastFloor.current;
    if (!phaseChanged && !floorChanged) return;

    const prev = lastPhase.current;
    lastPhase.current = phase;
    lastFloor.current = selectedFloor;

    if (prev === 'loading' || phase === 'loading') return;

    // If only the floor changed (same phase), re-run the current phase
    // transition so the extracted floor updates to the new floor.
    if (!phaseChanged && floorChanged) {
      // The phase didn't change but the floor did — re-run the same
      // phase transition to update the extracted floor content.
      // This handles the "click another floor while in floor_selecting"
      // race condition.
      runTransition(phase);
      return;
    }

    runTransition(phase);
  }, [phase, selectedFloor]);

  useFrame((_, delta) => {
    // Idle check — skip when settled
    const idle = !pendingFinalPhase
      && Math.abs(state.buildingX.cur - state.buildingX.tgt) < 0.001
      && Math.abs(state.buildingOpacity.cur - state.buildingOpacity.tgt) < 0.001
      && Math.abs(state.floorX.cur - state.floorX.tgt) < 0.001
      && Math.abs(state.floorScale.cur - state.floorScale.tgt) < 0.001
      && Math.abs(state.floorOpacity.cur - state.floorOpacity.tgt) < 0.001
      && state.cameraPos.cur.distanceTo(state.cameraPos.tgt) < 0.01;
    if (idle) return;

    const lerpFactor = 1 - Math.pow(1 - LERP, delta * 60);

    // Building X
    state.buildingX.cur += (state.buildingX.tgt - state.buildingX.cur) * lerpFactor;
    if (refs.building) refs.building.position.x = state.buildingX.cur;

    // Building opacity
    state.buildingOpacity.cur += (state.buildingOpacity.tgt - state.buildingOpacity.cur) * lerpFactor;
    if (refs.building && (state.buildingOpacity.cur < 0.99 || state.buildingOpacity.tgt < 0.99)) {
      refs.building.traverse((obj: any) => {
        if (obj.material && obj.material.opacity !== undefined) {
          if (obj.material.userData?.viewerFade) return;
          if (obj.material.userData?._origOpacity === undefined) {
            obj.material.userData._origOpacity = obj.material.opacity;
          }
          obj.material.transparent = true;
          obj.material.opacity = obj.material.userData._origOpacity * state.buildingOpacity.cur;
        }
      });
      refs.building.visible = state.buildingOpacity.cur > 0.01;
    }

    // Camera
    state.cameraPos.cur.lerp(state.cameraPos.tgt, lerpFactor);
    state.cameraTarget.cur.lerp(state.cameraTarget.tgt, lerpFactor);
    if (refs.camera && refs.controls) {
      refs.camera.position.copy(state.cameraPos.cur);
      refs.controls.target.copy(state.cameraTarget.cur);
      refs.controls.update();
    }

    // Extracted floor
    state.floorX.cur += (state.floorX.tgt - state.floorX.cur) * lerpFactor;
    state.floorScale.cur += (state.floorScale.tgt - state.floorScale.cur) * lerpFactor;
    state.floorOpacity.cur += (state.floorOpacity.tgt - state.floorOpacity.cur) * lerpFactor;
    if (refs.extractedFloor) {
      const ef = refs.extractedFloor;
      ef.position.x = state.floorX.cur;
      ef.scale.setScalar(state.floorScale.cur);
      ef.visible = state.floorOpacity.cur > 0.01;
      if (state.floorOpacity.cur < 0.99 || state.floorOpacity.tgt < 0.99) {
        ef.traverse((obj: any) => {
          if (obj.material && obj.material.userData?.viewerFade) {
            obj.material.opacity = state.floorOpacity.cur * (obj.material.userData._baseOpacity ?? 1);
          }
        });
      }
    }

    // Flip phase after duration
    if (pendingFinalPhase) {
      const elapsed = performance.now() - transitionStart;
      const needed = PHASE_DURATIONS[pendingFinalPhase === 'overview'
        ? 'returning'
        : pendingFinalPhase === 'extracted'
          ? 'floor_selecting'
          : pendingFinalPhase === 'floor_inspecting'
            ? 'floor_inspect_selecting'
            : 'floor_inspect_returning'] ?? 1000;
      if (elapsed > needed) {
        const next = pendingFinalPhase;
        pendingFinalPhase = null;
        if (next === 'overview') {
          useViewerStore.setState({
            phase: 'overview',
            selectedFloor: null,
            selectedUnitId: null,
            hoveredUnitId: null,
            tooltipFloor: null,
          });
        } else {
          useViewerStore.getState().setPhase(next);
        }
      }
    }
  });
}
