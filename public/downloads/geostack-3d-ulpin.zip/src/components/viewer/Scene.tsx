'use client';

/**
 * Scene.tsx — the contents rendered inside the R3F Canvas.
 *
 * Drives the background/fog/grid colors based on `xrayMode`:
 *  - X-RAY OFF: dark background (#0b0e12) + dark grid (premium digital-twin look)
 *  - X-RAY ON:  white background (#f5f5f7) + dark grid + transparent walls
 *              (matches the reference "glass-box architectural visualization")
 */

import { OrbitControls } from '@react-three/drei';
import * as THREE from 'three';
import Building from './Building';
import ExtractedFloor from './ExtractedFloor';
import Lighting from './Lighting';
import CameraRig from './CameraRig';
import { useViewerStore } from '@/lib/viewer-store';
import { useTransitionController } from './useTransitionController';

export default function Scene() {
  const phase = useViewerStore((s) => s.phase);
  const xrayMode = useViewerStore((s) => s.xrayMode);
  useTransitionController();

  // X-ray colors: white background, lighter fog, dark grid lines
  const bgColor = xrayMode ? '#F5F7FA' : '#0b0e12';
  const fogColor = xrayMode ? '#F5F7FA' : '#0b0e12';
  const fogNear = xrayMode ? 100 : 70;
  const fogFar = xrayMode ? 250 : 160;
  const gridSectionColor = xrayMode ? '#3b3b40' : '#2c3a45';
  const gridColor = xrayMode ? '#9da3ac' : '#1d2730';

  return (
    <>
      <color attach="background" args={[bgColor]} />
      <fog attach="fog" args={[fogColor, fogNear, fogFar]} />

      <Lighting />

      {/* Main building */}
      <Building />

      {/* Extracted floor — renders when a floor is selected.
          Step 1: in 'extracted' phase, the floor is on the RIGHT side
                  (building on LEFT, both visible).
          Step 2: in 'floor_inspecting' phase, the floor is centered as
                  the SOLO main 3D item (building hidden).
          The transition controller animates the position+scale+opacity
          between these layouts. */}
      {(phase === 'floor_selecting' || phase === 'extracted' || phase === 'floor_inspect_selecting' || phase === 'floor_inspecting' || phase === 'floor_inspect_returning' || phase === 'returning') && (
        <ExtractedFloor />
      )}

      {/* Ground grid — color depends on X-ray mode */}
      <gridHelper
        args={[120, 60, gridSectionColor, gridColor]}
        position={[0, xrayMode ? -7 : 0.01, 0]}
      />

      <CameraRig />

      <OrbitControls
        makeDefault
        enablePan={true}
        enableDamping
        dampingFactor={0.08}
        minDistance={5}
        maxDistance={150}
        maxPolarAngle={Math.PI - 0.05}
        minPolarAngle={0.05}
        target={[0, 20, 0]}
        panSpeed={0.5}
        rotateSpeed={0.65}
        zoomSpeed={0.8}
      />
    </>
  );
}
