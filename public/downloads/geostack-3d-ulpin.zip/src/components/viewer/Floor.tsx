'use client';

/**
 * Floor.tsx
 *
 * Each floor is a self-contained R3F group containing:
 *  - The concrete floor slab (with a visible band / soffit)
 *  - The facade walls (front + back + 2 short sides)
 *  - Glass + mullions (per window opening)
 *  - Balcony slabs + railings on the long facades
 *  - A "halo" overlay that fades in on hover/selection
 *
 * The floor group is interactive: pointer-over / pointer-out / click all
 * dispatch into the Zustand store. Selection state is reflected by
 * raising the floor a few cm + tinting the facade with an accent
 * emissive.
 */

import { useMemo, useRef, useState, useEffect } from 'react';
import { ThreeEvent } from '@react-three/fiber';
import * as THREE from 'three';

import type { Floor as FloorData } from '@/lib/building-data';
import { useViewerStore } from '@/lib/viewer-store';
import {
  matConcrete,
  matSlabEdge,
  matSoffit,
  matGlass,
  matMullion,
  matBalconyTile,
  matRailing,
  matBasement,
  matXrayFacade,
  matXraySlab,
  matXrayWireframe,
  makeFacadeHighlight,
} from '@/lib/viewer-materials';

interface FloorProps {
  floor: FloorData;
  y: number;
  isTopFloor: boolean;
}

const HOVER_TINT = '#C7D2FE';    // indigo-200
const SELECTED_TINT = '#6366F1'; // indigo-500

export default function Floor({ floor, y, isTopFloor }: FloorProps) {
  const groupRef = useRef<THREE.Group>(null);
  const liftRef = useRef<THREE.Group>(null); // inner group — only Y lift
  const facadeNorthRef = useRef<THREE.Mesh>(null);
  const facadeSouthRef = useRef<THREE.Mesh>(null);
  const facadeEastRef = useRef<THREE.Mesh>(null);
  const facadeWestRef = useRef<THREE.Mesh>(null);
  const haloRef = useRef<THREE.Mesh>(null);
  const [_, setHovered] = useState(false);

  const hoveredFloor = useViewerStore((s) => s.hoveredFloor);
  const selectedFloor = useViewerStore((s) => s.selectedFloor);
  const phase = useViewerStore((s) => s.phase);
  const xrayMode = useViewerStore((s) => s.xrayMode);
  const hoverFloor = useViewerStore((s) => s.hoverFloor);
  const selectFloor = useViewerStore((s) => s.selectFloor);
  const setPhase = useViewerStore((s) => s.setPhase);

  const mats = useMemo(
    () => ({
      hoverMat: makeFacadeHighlight(HOVER_TINT, 0.18),
      selectedMat: makeFacadeHighlight(SELECTED_TINT, 0.45),
    }),
    [],
  );

  const isSelected = selectedFloor === floor.floorNumber;
  const isHovered = hoveredFloor === floor.floorNumber && !isSelected;

  // Floor dimensions
  const W = 20;
  const D = 16;
  const H = floor.height; // 3.0 m
  const wallThickness = 0.18;
  const slabThickness = 0.22;

  /* ------------------- per-variant balcony layout -------------------- */

  const balconyLayout = useMemo(() => {
    const v = floor.variant;
    if (v === 0) {
      return [
        { side: 'north' as const, xStart: -W / 2 + 1.5, width: 5 },
        { side: 'south' as const, xStart: W / 2 - 6.5, width: 5 },
      ];
    }
    if (v === 1) {
      return [
        { side: 'north' as const, xStart: W / 2 - 6.5, width: 5 },
        { side: 'south' as const, xStart: -W / 2 + 1.5, width: 5 },
      ];
    }
    return [
      { side: 'north' as const, xStart: -W / 2 + 1.5, width: 5 },
      { side: 'south' as const, xStart: -W / 2 + 1.5, width: 5 },
    ];
  }, [floor.variant, W]);

  /* ------------------- window modules -------------------- */

  const longWindows = useMemo(() => {
    const cols = 4; // was 6 — fewer windows = fewer meshes
    const cw = (W - 0.6) / cols;
    return Array.from({ length: cols }, (_, i) => ({
      x: -W / 2 + 0.3 + i * cw + cw / 2,
      y: -0.1,
      w: cw * 0.78,
      h: 1.5,
    }));
  }, [W]);

  const shortWindows = useMemo(() => {
    const cols = 2;
    const cw = (D - 0.6) / cols;
    return Array.from({ length: cols }, (_, i) => ({
      z: -D / 2 + 0.3 + i * cw + cw / 2,
      y: -0.1,
      w: cw * 0.6,
      h: 1.4,
    }));
  }, [D]);

  /* ------------------- hover + selection effects (no per-frame lerp) -------------------- */

  // Update lift position when isSelected changes (no per-frame work).
  useEffect(() => {
    if (!liftRef.current) return;
    const targetY = isSelected && (phase === 'extracted' || phase === 'floor_selecting' || phase === 'floor_inspecting' || phase === 'floor_inspect_selecting') ? 0.35 : 0;
    liftRef.current.position.y = targetY;
  }, [isSelected, phase]);

  // Swap facade material based on hover/selection/xray state.
  // Priority: xray > selected > hover > default (basement or concrete)
  const targetMat = xrayMode
    ? matXrayFacade
    : isSelected
      ? mats.selectedMat
      : isHovered
        ? mats.hoverMat
        : floor.isUnderground
          ? matBasement
          : matConcrete;

  useEffect(() => {
    for (const ref of [facadeNorthRef, facadeSouthRef, facadeEastRef, facadeWestRef]) {
      if (ref.current) {
        ref.current.material = targetMat;
      }
    }
  }, [targetMat]);

  // Update halo opacity on hover/selection change.
  useEffect(() => {
    if (!haloRef.current) return;
    const mat = haloRef.current.material as THREE.MeshBasicMaterial;
    const targetOpacity = isSelected ? 0.22 : isHovered ? 0.10 : 0.0;
    mat.opacity = targetOpacity;
  }, [isSelected, isHovered]);

  /* ------------------- handlers -------------------- */

  const onPointerOver = (e: ThreeEvent<PointerEvent>) => {
    e.stopPropagation();
    setHovered(true);
    hoverFloor(floor.floorNumber);
    useViewerStore.setState({ tooltipFloor: floor.floorNumber });
    document.body.style.cursor = 'pointer';
  };

  const onPointerOut = (e: ThreeEvent<PointerEvent>) => {
    e.stopPropagation();
    setHovered(false);
    hoverFloor(null);
    useViewerStore.setState({ tooltipFloor: null });
    document.body.style.cursor = 'default';
  };

  const onClick = (e: ThreeEvent<MouseEvent>) => {
    e.stopPropagation();
    // If clicking the SAME floor that's already selected → collapse back to overview
    if (isSelected && (phase === 'extracted' || phase === 'floor_selecting' || phase === 'floor_inspecting' || phase === 'floor_inspect_selecting' || phase === 'floor_inspect_returning')) {
      setPhase('returning');
      return;
    }
    // If clicking a DIFFERENT floor while in ANY inspection/transition mode → switch directly
    if (!isSelected && (phase === 'extracted' || phase === 'floor_selecting' || phase === 'floor_inspecting' || phase === 'floor_inspect_selecting' || phase === 'floor_inspect_returning')) {
      selectFloor(floor.floorNumber);
      // Re-trigger the selecting transition for the new floor.
      // Even if phase is already 'floor_selecting', setting it again
      // + the selectedFloor change will cause the transition controller
      // to re-run.
      setPhase('floor_selecting');
      return;
    }
    // Normal: only allow new selection from overview phase
    if (phase !== 'overview') return;
    selectFloor(floor.floorNumber);
    setPhase('floor_selecting');
  };

  /* ------------------- render -------------------- */

  return (
    <group
      ref={groupRef}
      position={[0, y, 0]}
      onPointerOver={onPointerOver}
      onPointerOut={onPointerOut}
      onClick={onClick}
    >
      <group ref={liftRef} position={[0, 0, 0]}>
      {/* Slab (floor + ceiling combined as a single thick box). */}
      <mesh position={[0, -H / 2 + slabThickness / 2, 0]} material={xrayMode ? matXraySlab : floor.isUnderground ? matBasement : matSlabEdge}>
        <boxGeometry args={[W + 0.15, slabThickness, D + 0.15]} />
      </mesh>
      {!xrayMode && (
        <mesh position={[0, -H / 2 + slabThickness + 0.02, 0]} material={matSoffit}>
          <boxGeometry args={[W + 0.2, 0.06, D + 0.2]} />
        </mesh>
      )}

      {/* Floor separation band — hidden in X-ray mode (would obscure interior). */}
      {!xrayMode && (
        <mesh position={[0, H / 2 - 0.06, 0]} material={matSoffit}>
          <boxGeometry args={[W + 0.25, 0.14, D + 0.25]} />
        </mesh>
      )}

      {/* Long facades. */}
      <mesh
        ref={facadeNorthRef}
        position={[0, 0, -D / 2 + wallThickness / 2]}
        material={matConcrete}
       
      >
        <boxGeometry args={[W, H - slabThickness * 1.5, wallThickness]} />
      </mesh>
      <mesh
        ref={facadeSouthRef}
        position={[0, 0, D / 2 - wallThickness / 2]}
        material={matConcrete}
       
      >
        <boxGeometry args={[W, H - slabThickness * 1.5, wallThickness]} />
      </mesh>
      {/* Short facades. */}
      <mesh
        ref={facadeEastRef}
        position={[W / 2 - wallThickness / 2, 0, 0]}
        material={matConcrete}
       
      >
        <boxGeometry args={[wallThickness, H - slabThickness * 1.5, D]} />
      </mesh>
      <mesh
        ref={facadeWestRef}
        position={[-W / 2 + wallThickness / 2, 0, 0]}
        material={matConcrete}
       
      >
        <boxGeometry args={[wallThickness, H - slabThickness * 1.5, D]} />
      </mesh>

      {/* Long-facade windows */}
      {(['north', 'south'] as const).map((side) =>
        longWindows.map((w, i) => (
          <WindowModule
            key={`${side}-${i}`}
            position={[w.x, w.y, side === 'north' ? -D / 2 + 0.05 : D / 2 - 0.05]}
            rotation={[0, side === 'north' ? 0 : Math.PI, 0]}
            width={w.w}
            height={w.h}
          />
        )),
      )}

      {/* Short-facade windows */}
      {(['east', 'west'] as const).map((side) =>
        shortWindows.map((w, i) => (
          <WindowModule
            key={`${side}-${i}`}
            position={[side === 'east' ? W / 2 - 0.05 : -W / 2 + 0.05, w.y, w.z]}
            rotation={[0, side === 'east' ? Math.PI / 2 : -Math.PI / 2, 0]}
            width={w.w}
            height={w.h}
          />
        )),
      )}

      {/* Balconies — hidden in X-ray mode for cleaner interior view */}
      {!xrayMode && !floor.isUnderground && balconyLayout.map((b, i) => {
        const isNorth = b.side === 'north';
        const z = isNorth ? -D / 2 - 0.45 : D / 2 + 0.45;
        return (
          <Balcony
            key={`bal-${i}`}
            position={[b.xStart + b.width / 2, -H / 2 + slabThickness + 0.02, z]}
            width={b.width}
            depth={1.2}
            height={H - slabThickness * 1.5 - 0.1}
            flipZ={!isNorth}
          />
        );
      })}

      {/* Halo — a slightly larger transparent shell that glows on hover/select. */}
      {!xrayMode && (
        <mesh ref={haloRef} position={[0, 0, 0]}>
          <boxGeometry args={[W + 0.4, H + 0.15, D + 0.4]} />
          <meshBasicMaterial
            color={new THREE.Color(SELECTED_TINT)}
            transparent
            opacity={0}
            side={THREE.BackSide}
            depthWrite={false}
          />
        </mesh>
      )}

      {/* X-ray mode: walls stay (very transparent), but we add:
          - Wireframe edge lines on each facade (visible as faint outlines)
          - 8 solid pillars (corner + mid-edge) as slate-blue boxes
          - Central core (4 thin walls)
          - Interior floor plan lines on the slab (room divisions, doors)
          Only the wireframe overlay is "new" geometry — walls themselves
          become nearly invisible via the matXrayFacade material. */}
      {xrayMode && (
        <XrayInterior W={W} D={D} H={H} slabThickness={slabThickness} />
      )}

      {/* Invisible click target — a slightly larger box that ensures
          clicks anywhere over the floor's footprint register reliably,
          even between window mullions. Transparent material with 0
          opacity — still pickable by the raycaster. */}
      <mesh position={[0, 0, 0]}>
        <boxGeometry args={[W + 0.5, H + 0.1, D + 0.5]} />
        <meshBasicMaterial transparent opacity={0} depthWrite={false} />
      </mesh>
      </group>
    </group>
  );
}

/* ------------------------------------------------------------------ */
/* Window module                                                       */
/* ------------------------------------------------------------------ */

interface WindowModuleProps {
  position: [number, number, number];
  rotation: [number, number, number];
  width: number;
  height: number;
}

function WindowModule({ position, rotation, width, height }: WindowModuleProps) {
  // Minimal: 1 glass pane + 1 frame box (slightly larger). Cuts mesh
  // count from 5+ per window down to 2 — with ~170 windows in the
  // tower, that's a saving of ~500 meshes per frame.
  return (
    <group position={position} rotation={rotation}>
      {/* Frame box (slightly larger, dark) */}
      <mesh material={matMullion} position={[0, 0, 0]}>
        <boxGeometry args={[width, height, 0.08]} />
      </mesh>
      {/* Glass pane (inset, slightly brighter) */}
      <mesh material={matGlass} position={[0, 0, 0.01]}>
        <boxGeometry args={[width * 0.88, height * 0.88, 0.06]} />
      </mesh>
    </group>
  );
}

/* ------------------------------------------------------------------ */
/* Balcony                                                             */
/* ------------------------------------------------------------------ */

interface BalconyProps {
  position: [number, number, number];
  width: number;
  depth: number;
  height: number;
  flipZ: boolean;
}

function Balcony({ position, width, depth, height, flipZ }: BalconyProps) {
  const slabY = -height / 2;
  const railingH = 1.05;
  const frontZ = flipZ ? -depth : depth;
  const sideZ = flipZ ? -depth / 2 : depth / 2;

  return (
    <group position={position}>
      {/* Slab */}
      <mesh
        position={[0, slabY + 0.04, flipZ ? -depth / 2 : depth / 2]}
        material={matBalconyTile}
      >
        <boxGeometry args={[width, 0.08, depth]} />
      </mesh>
      {/* Soffit */}
      <mesh position={[0, slabY, flipZ ? -depth / 2 : depth / 2]} material={matSoffit}>
        <boxGeometry args={[width + 0.02, 0.04, depth + 0.02]} />
      </mesh>

      {/* Front railing — top + mid rail + posts */}
      <RailingSegment
        length={width}
        height={railingH}
        position={[0, slabY + 0.06, frontZ]}
        axis="x"
      />
      {/* Left + right side railings */}
      <RailingSegment
        length={depth}
        height={railingH}
        position={[-width / 2, slabY + 0.06, sideZ]}
        axis="z"
      />
      <RailingSegment
        length={depth}
        height={railingH}
        position={[width / 2, slabY + 0.06, sideZ]}
        axis="z"
      />

      {/* Parapet edge */}
      <mesh
        position={[0, slabY + 0.08, flipZ ? -depth + 0.04 : depth - 0.04]}
        material={matRailing}
      >
        <boxGeometry args={[width, 0.16, 0.06]} />
      </mesh>
    </group>
  );
}

/* ------------------------------------------------------------------ */
/* Railing — minimal: top rail + 2 corner posts (no middle posts).   */
/* Consolidated to keep mesh count low (was: ~10/railing, now: 3).    */
/* ------------------------------------------------------------------ */

function RailingSegment({
  length,
  height,
  position,
  axis,
}: {
  length: number;
  height: number;
  position: [number, number, number];
  axis: 'x' | 'z';
}) {
  // axis = 'x' means the railing runs along X; 'z' means along Z.
  const railGeo = axis === 'x'
    ? new THREE.BoxGeometry(length, 0.05, 0.05)
    : new THREE.BoxGeometry(0.05, 0.05, length);
  const postGeo = new THREE.BoxGeometry(0.05, height, 0.05);

  return (
    <group position={position} material={matRailing}>
      {/* Top rail (single mesh) */}
      <mesh geometry={railGeo} position={[0, height - 0.025, 0]} />
      {/* Mid rail (single mesh) */}
      <mesh geometry={railGeo} position={[0, height * 0.55, 0]} scale={[1, 0.6, 1]} />
      {/* 2 corner posts only */}
      <mesh geometry={postGeo} position={axis === 'x' ? [-length / 2, height / 2, 0] : [0, height / 2, -length / 2]} />
      <mesh geometry={postGeo} position={axis === 'x' ? [length / 2, height / 2, 0] : [0, height / 2, length / 2]} />
    </group>
  );
}

/* ------------------------------------------------------------------ */
/* X-ray interior structure                                            */
/* ------------------------------------------------------------------ */
/* In X-ray mode, the facades are nearly transparent (via matXrayFacade).
 * This component adds the visible "skeleton" + interior floor plan:
 *
 *  - Wireframe edge lines on each facade (using EdgesGeometry —
 *    only the silhouette + hard edges, no diagonal lines)
 *  - 8 solid pillars (4 corner + 4 mid-edge) — slate-blue boxes
 *  - Central core walls (4 thin walls around the lift + stair)
 *  - Interior floor plan lines on the slab (unit boundaries + the
 *    central core outline + door swings on each unit's core-facing
 *    wall) — drawn as thin Line segments at slab-top height
 */

interface XrayInteriorProps {
  W: number;
  D: number;
  H: number;
  slabThickness: number;
}

function XrayInterior({ W, D, H, slabThickness }: XrayInteriorProps) {
  const wallH = H - slabThickness * 1.5;
  const wallY = 0; // facades are centered at y=0
  const wallT = 0.18;

  // Wireframe geometries for each facade
  const facadeEdges = useMemo(() => {
    const long = new THREE.EdgesGeometry(new THREE.BoxGeometry(W, wallH, wallT));
    const short = new THREE.EdgesGeometry(new THREE.BoxGeometry(wallT, wallH, D));
    return { long, short };
  }, [W, D, wallH, wallT]);

  // Pillar positions (4 corner + 4 mid-edge)
  const pillars = useMemo(() => {
    const ps: [number, number, number][] = [
      // 4 corners
      [W / 2 - 0.4, -D / 2 + 0.4],
      [-W / 2 + 0.4, -D / 2 + 0.4],
      [W / 2 - 0.4, D / 2 - 0.4],
      [-W / 2 + 0.4, D / 2 - 0.4],
      // 4 mid-edge
      [0, -D / 2 + 0.4],
      [0, D / 2 - 0.4],
      [W / 2 - 0.4, 0],
      [-W / 2 + 0.4, 0],
    ];
    return ps;
  }, [W, D]);

  // Pillar geometry — solid slate-blue box (visible as solid lines from any angle)
  const pillarGeo = useMemo(() => new THREE.BoxGeometry(0.22, wallH, 0.22), [wallH]);
  // Pillar wireframe edges (thinner lines on top of the solid box for crisp outline)
  const pillarEdges = useMemo(() => new THREE.EdgesGeometry(pillarGeo), [pillarGeo]);

  // Core walls (4 thin walls around the 4×4 lift + stair core)
  const coreWalls = useMemo(() => {
    const CORE_W = 4;
    const CORE_D = 4;
    return [
      { pos: [0, 0, -CORE_D / 2] as [number, number, number], args: [CORE_W, wallH, 0.08] as [number, number, number] },
      { pos: [0, 0, CORE_D / 2] as [number, number, number], args: [CORE_W, wallH, 0.08] as [number, number, number] },
      { pos: [CORE_W / 2, 0, 0] as [number, number, number], args: [0.08, wallH, CORE_D] as [number, number, number] },
      { pos: [-CORE_W / 2, 0, 0] as [number, number, number], args: [0.08, wallH, CORE_D] as [number, number, number] },
    ];
  }, [wallH]);

  // Interior floor plan lines — drawn as a single LineSegments on top of the slab.
  // Each unit is 6.5 × 5m arranged in NE/NW/SW/SE quadrants around the 4×4 core.
  const UNIT_W = 6.5;
  const UNIT_D = 5.0;
  const CORE = 4;
  const planY = -H / 2 + slabThickness + 0.1; // 10cm above the slab so it's clearly visible

  const floorPlanGeo = useMemo(() => {
    const verts: number[] = [];
    const pushLine = (x1: number, z1: number, x2: number, z2: number) => {
      verts.push(x1, planY, z1, x2, planY, z2);
    };

    // Central core outline (4×4 square)
    pushLine(-CORE / 2, -CORE / 2, CORE / 2, -CORE / 2);
    pushLine(CORE / 2, -CORE / 2, CORE / 2, CORE / 2);
    pushLine(CORE / 2, CORE / 2, -CORE / 2, CORE / 2);
    pushLine(-CORE / 2, CORE / 2, -CORE / 2, -CORE / 2);

    // Unit boundaries (the 4 quadrants)
    // Gap between core and units: 0.8m
    // Unit width: 6.5, depth: 5
    // NE unit: from (CORE/2 + 0.8, -W/2...) wait, x is width, z is depth.
    // Let me redo this — building width is W=20 (X), depth is D=16 (Z).
    // Units are arranged at:
    //   NE: x in (0.8 + CORE/2, 0.8 + CORE/2 + UNIT_W), z in -(0.8 + CORE/2 + UNIT_D), -(0.8 + CORE/2)
    // Hmm, let me just use the unitCenters from the ExtractedFloor data and draw each unit's outline.

    const unitCenters = [
      { x: 0.8 + CORE / 2 + UNIT_W / 2, z: -(0.8 + CORE / 2 + UNIT_D / 2) },  // NE
      { x: -(0.8 + CORE / 2 + UNIT_W / 2), z: -(0.8 + CORE / 2 + UNIT_D / 2) }, // NW
      { x: -(0.8 + CORE / 2 + UNIT_W / 2), z: 0.8 + CORE / 2 + UNIT_D / 2 },  // SW
      { x: 0.8 + CORE / 2 + UNIT_W / 2, z: 0.8 + CORE / 2 + UNIT_D / 2 },    // SE
    ];

    for (const uc of unitCenters) {
      const x1 = uc.x - UNIT_W / 2;
      const x2 = uc.x + UNIT_W / 2;
      const z1 = uc.z - UNIT_D / 2;
      const z2 = uc.z + UNIT_D / 2;
      pushLine(x1, z1, x2, z1);
      pushLine(x2, z1, x2, z2);
      pushLine(x2, z2, x1, z2);
      pushLine(x1, z2, x1, z1);

      // Interior partition (splits the unit into 2 rooms)
      pushLine(uc.x, z1, uc.x, z2);

      // Door swing on the core-facing wall (an arc approximated by 3 line segments)
      // The door is on the wall facing the centre (0,0)
      const towardsCenterAngle = Math.atan2(-uc.z, -uc.x);
      const doorX = uc.x + Math.cos(towardsCenterAngle) * (UNIT_W / 2);
      const doorZ = uc.z + Math.sin(towardsCenterAngle) * (UNIT_D / 2);
      // Door opening width: 1m
      const doorPerpX = -Math.sin(towardsCenterAngle);
      const doorPerpZ = Math.cos(towardsCenterAngle);
      pushLine(doorX - 0.5 * doorPerpX, doorZ - 0.5 * doorPerpZ, doorX + 0.5 * doorPerpX, doorZ + 0.5 * doorPerpZ);
    }

    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.Float32BufferAttribute(verts, 3));
    return geo;
  }, [W, D, H, slabThickness, planY]);

  // Floor plan line material — slate blue, bolder (opacity 0.85) so it's clearly visible
  const planMat = useMemo(() => new THREE.LineBasicMaterial({
    color: new THREE.Color('#1a3a5c'),
    transparent: true,
    opacity: 0.85,
  }), []);

  // Pillar material — solid slate blue
  const pillarMat = useMemo(() => new THREE.MeshStandardMaterial({
    color: new THREE.Color('#34495e'),
    roughness: 0.4,
    metalness: 0.1,
    transparent: true,
    opacity: 0.85,
  }), []);

  // Pillar wireframe material — slightly darker line
  const pillarLineMat = useMemo(() => new THREE.LineBasicMaterial({
    color: new THREE.Color('#1a252f'),
    transparent: true,
    opacity: 0.9,
  }), []);

  return (
    <group>
      {/* Wireframe edges on each facade — visible as faint outlines
          so the building silhouette is still readable. */}
      <lineSegments
        geometry={facadeEdges.long}
        material={matXrayWireframe}
        position={[0, wallY, -D / 2 + wallT / 2]}
      />
      <lineSegments
        geometry={facadeEdges.long}
        material={matXrayWireframe}
        position={[0, wallY, D / 2 - wallT / 2]}
      />
      <lineSegments
        geometry={facadeEdges.short}
        material={matXrayWireframe}
        position={[W / 2 - wallT / 2, wallY, 0]}
      />
      <lineSegments
        geometry={facadeEdges.short}
        material={matXrayWireframe}
        position={[-W / 2 + wallT / 2, wallY, 0]}
      />

      {/* 8 solid pillars (slate-blue boxes with dark wireframe outline) */}
      {pillars.map(([px, pz], i) => (
        <group key={`pillar-${i}`} position={[px, 0, pz]}>
          <mesh geometry={pillarGeo} material={pillarMat} />
          <lineSegments geometry={pillarEdges} material={pillarLineMat} />
        </group>
      ))}

      {/* Central core walls (slate-blue, semi-transparent) */}
      {coreWalls.map((c, i) => (
        <mesh key={`core-${i}`} position={c.pos} material={pillarMat}>
          <boxGeometry args={c.args} />
        </mesh>
      ))}

      {/* Interior floor plan lines on the slab top */}
      <lineSegments geometry={floorPlanGeo} material={planMat} />
    </group>
  );
}
