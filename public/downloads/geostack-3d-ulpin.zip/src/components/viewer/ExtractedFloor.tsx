'use client';

/**
 * ExtractedFloor.tsx
 *
 * The "drill-down" 3D model that appears on the right side of the
 * viewer once a floor is selected. It is a fully 3D floor plate
 * containing 4 apartment units arranged around a central core.
 *
 * Animations are driven by the central GSAP transition controller —
 * this component just registers its group ref and renders the
 * geometry. No per-frame lerp = no jank.
 *
 * Each unit is interactive: hover highlights it + emits a hover
 * state; click selects it and surfaces its ULPIN into the UI panel.
 */

import { useEffect, useMemo, useRef } from 'react';
import { ThreeEvent } from '@react-three/fiber';
import * as THREE from 'three';
import { useViewerStore, useBuilding } from '@/lib/viewer-store';
import { registerRef } from './useTransitionController';
import {
  matSlabEdge,
  matSoffit,
  matConcrete,
  matGlass,
  matMullion,
  matBalconyTile,
  matRailing,
  matMech,
  matXrayFacade,
  matXraySlab,
  matXrayWireframe,
  makeFacadeHighlight,
  makeXrayHighlight,
} from '@/lib/viewer-materials';

const SELECTED_TINT = '#41e6ec';
const HOVER_TINT = '#7df0f4';

// Layout constants
const FLOOR_W = 18;
const FLOOR_D = 14;
const SLAB_T = 0.25;
const WALL_T = 0.15;
const CORE_W = 4.0;
const CORE_D = 4.0;
const UNIT_W = 6.5;
const UNIT_D = 5.0;

export default function ExtractedFloor() {
  const groupRef = useRef<THREE.Group>(null);
  const selectedFloor = useViewerStore((s) => s.selectedFloor);
  const phase = useViewerStore((s) => s.phase);
  const xrayMode = useViewerStore((s) => s.xrayMode);
  const setPhase = useViewerStore((s) => s.setPhase);
  const building = useBuilding();

  const floor = useMemo(
    () => building.floors.find((f) => f.floorNumber === selectedFloor) ?? null,
    [building, selectedFloor],
  );

  // Register this group + manage visibility directly to avoid the
  // race condition where the transition controller's idle check skips
  // the visibility update during direct floor switching.
  useEffect(() => {
    if (!groupRef.current) return;
    registerRef('extractedFloor', groupRef.current);

    // If we're in a phase where the floor should be visible, force
    // the group visible + set material opacities immediately. This
    // prevents the "walls absent" bug when switching floors.
    const shouldShow = phase !== 'overview' && phase !== 'loading' && phase !== 'returning';
    if (shouldShow) {
      groupRef.current.visible = true;
      // Force all fade-tagged materials to their correct opacity
      groupRef.current.traverse((obj: any) => {
        if (obj.material && obj.material.userData?.viewerFade) {
          const base = obj.material.userData._baseOpacity ?? 1;
          obj.material.opacity = base; // floorOpacity is ~1 in visible phases
          obj.material.transparent = true;
        }
      });
    } else {
      groupRef.current.visible = false;
    }
  }, [phase, selectedFloor]);

  if (!floor) return null;

  const unitCenters = [
    { x: 0.8 + UNIT_W / 2, z: -(0.8 + UNIT_D / 2), idx: 0 },
    { x: -(0.8 + UNIT_W / 2), z: -(0.8 + UNIT_D / 2), idx: 1 },
    { x: -(0.8 + UNIT_W / 2), z: 0.8 + UNIT_D / 2, idx: 2 },
    { x: 0.8 + UNIT_W / 2, z: 0.8 + UNIT_D / 2, idx: 3 },
  ];

  // Click on the floor plate (not on a unit) → enter solo inspect mode.
  // (Clicking a unit just selects it for the info panel.)
  const onFloorClick = (e: ThreeEvent<MouseEvent>) => {
    e.stopPropagation();
    if (phase !== 'extracted') return;
    setPhase('floor_inspect_selecting');
  };

  return (
    <group ref={groupRef} position={[24, 8, 0]} scale={0.6}>
      {/* Floor plate is clickable to enter solo inspect mode */}
      <group onClick={onFloorClick}>
        <FloorPlate width={FLOOR_W} depth={FLOOR_D} xrayMode={xrayMode} />
        <CentralCore x={0} z={0} xrayMode={xrayMode} />
        <ConnectorLine fromX={-11} toX={0} y={0} />
      </group>
      {floor.units.map((u, i) => (
        <UnitBlock key={u.unitId} unit={u} center={unitCenters[i]} xrayMode={xrayMode} />
      ))}
      {/* X-ray interior floor plan lines on the slab */}
      {xrayMode && <ExtractedFloorPlan />}
    </group>
  );
}

/* ------------------------------------------------------------------ */
/* Floor plate                                                         */
/* ------------------------------------------------------------------ */

function FloorPlate({ width, depth, xrayMode }: { width: number; depth: number; xrayMode: boolean }) {
  return (
    <group>
      <mesh position={[0, -0.15, 0]} material={xrayMode ? matXraySlab : matSlabEdge}>
        <boxGeometry args={[width, SLAB_T, depth]} />
      </mesh>
      {!xrayMode && (
        <mesh position={[0, -0.275, 0]} material={matSoffit}>
          <boxGeometry args={[width + 0.02, 0.04, depth + 0.02]} />
        </mesh>
      )}
      {[
        { pos: [0, 0.05, -depth / 2], args: [width, 0.12, 0.05] },
        { pos: [0, 0.05, depth / 2], args: [width, 0.12, 0.05] },
        { pos: [width / 2, 0.05, 0], args: [0.05, 0.12, depth] },
        { pos: [-width / 2, 0.05, 0], args: [0.05, 0.12, depth] },
      ].map((p, i) => (
        <mesh key={i} position={p.pos as [number, number, number]} material={xrayMode ? matXraySlab : matSlabEdge}>
          <boxGeometry args={p.args as [number, number, number]} />
        </mesh>
      ))}
    </group>
  );
}

/* ------------------------------------------------------------------ */
/* Central core (lift + stair + corridor)                              */
/* ------------------------------------------------------------------ */

function CentralCore({ x, z, xrayMode }: { x: number; z: number; xrayMode: boolean }) {
  const coreH = 2.7;
  const coreMat = xrayMode ? matXrayFacade : matConcrete;
  return (
    <group position={[x, 0, z]}>
      <mesh position={[0, coreH / 2, -CORE_D / 2]} material={coreMat}>
        <boxGeometry args={[CORE_W, coreH, WALL_T]} />
      </mesh>
      <mesh position={[0, coreH / 2, CORE_D / 2]} material={coreMat}>
        <boxGeometry args={[CORE_W, coreH, WALL_T]} />
      </mesh>
      <mesh position={[CORE_W / 2, coreH / 2, 0]} material={coreMat}>
        <boxGeometry args={[WALL_T, coreH, CORE_D]} />
      </mesh>
      <mesh position={[-CORE_W / 2, coreH / 2, 0]} material={coreMat}>
        <boxGeometry args={[WALL_T, coreH, CORE_D]} />
      </mesh>
      <mesh position={[0, 0.7, -CORE_D / 2 - 0.01]} material={matMullion}>
        <boxGeometry args={[1.4, 1.6, 0.02]} />
      </mesh>
      <mesh position={[0, coreH + 0.2, 0]} material={matMech}>
        <boxGeometry args={[CORE_W * 0.7, 0.4, CORE_D * 0.7]} />
      </mesh>
    </group>
  );
}

/* ------------------------------------------------------------------ */
/* Apartment unit block                                                */
/* ------------------------------------------------------------------ */

interface UnitBlockProps {
  unit: {
    unitId: string;
    displayId: string;
    floorNumber: number;
    carpetArea: number;
    ulpin: string;
  };
  center: { x: number; z: number; idx: number };
  xrayMode: boolean;
}

function UnitBlock({ unit, center, xrayMode }: UnitBlockProps) {
  const groupRef = useRef<THREE.Group>(null);
  const hoveredUnitId = useViewerStore((s) => s.hoveredUnitId);
  const selectedUnitId = useViewerStore((s) => s.selectedUnitId);
  const hoverUnit = useViewerStore((s) => s.hoverUnit);
  const selectUnit = useViewerStore((s) => s.selectUnit);

  const isHovered = hoveredUnitId === unit.unitId;
  const isSelected = selectedUnitId === unit.unitId;

  const highlightMat = useMemo(() => makeFacadeHighlight(SELECTED_TINT, 0.3), []);
  const hoverMat = useMemo(() => makeFacadeHighlight(HOVER_TINT, 0.15), []);

  // Determine which side of the unit faces the centre (0,0).
  const facingCore: 'north' | 'south' | 'east' | 'west' =
    Math.abs(center.x) > Math.abs(center.z)
      ? center.x > 0 ? 'west' : 'east'
      : center.z > 0 ? 'north' : 'south';

  // Update lift + material swaps only on state change — no per-frame work.
  useEffect(() => {
    if (!groupRef.current) return;
    groupRef.current.position.y = isSelected ? 0.04 : 0;

    // When X-ray is ON, keep walls transparent even on hover/selection.
    // Use makeXrayHighlight (clones matXrayFacade, stays transparent)
    let targetWallMat: THREE.Material;
    if (xrayMode) {
      targetWallMat = isSelected
        ? makeXrayHighlight(SELECTED_TINT, 0.15)
        : isHovered
          ? makeXrayHighlight(HOVER_TINT, 0.12)
          : matXrayFacade;
    } else {
      targetWallMat = isSelected ? highlightMat : isHovered ? hoverMat : matConcrete;
    }
    groupRef.current.traverse((obj) => {
      const mesh = obj as THREE.Mesh;
      if (!mesh.material) return;
      const mat = mesh.material as THREE.Material;
      if (mat.userData?.viewerWall === true) {
        mesh.material = targetWallMat;
      }
    });
  }, [isSelected, isHovered, highlightMat, hoverMat, xrayMode]);

  const onPointerOver = (e: ThreeEvent<PointerEvent>) => {
    e.stopPropagation();
    hoverUnit(unit.unitId);
    document.body.style.cursor = 'pointer';
  };
  const onPointerOut = (e: ThreeEvent<PointerEvent>) => {
    e.stopPropagation();
    hoverUnit(null);
    document.body.style.cursor = 'default';
  };
  const onClick = (e: ThreeEvent<MouseEvent>) => {
    e.stopPropagation();
    // Solo floor mode: clicking a unit just selects it (shows info
    // panel on the right). The floor stays as the main 3D item;
    // no separate "unit inspector" phase.
    selectUnit(unit.unitId);
  };

  const wallH = 2.7;
  const wallY = wallH / 2;
  const walls: {
    pos: [number, number, number];
    args: [number, number, number];
    side: 'north' | 'south' | 'east' | 'west';
  }[] = [
    { pos: [0, wallY, -UNIT_D / 2], args: [UNIT_W, wallH, WALL_T], side: 'north' },
    { pos: [0, wallY, UNIT_D / 2], args: [UNIT_W, wallH, WALL_T], side: 'south' },
    { pos: [UNIT_W / 2, wallY, 0], args: [WALL_T, wallH, UNIT_D], side: 'east' },
    { pos: [-UNIT_W / 2, wallY, 0], args: [WALL_T, wallH, UNIT_D], side: 'west' },
  ];

  return (
    <group
      ref={groupRef}
      position={[center.x, 0, center.z]}
      onPointerOver={onPointerOver}
      onPointerOut={onPointerOut}
      onClick={onClick}
    >
      {walls.map((w, i) => {
        const isCoreFacing = w.side === facingCore;
        if (isCoreFacing) {
          const doorW = 1.0;
          const wallExtent = w.side === 'north' || w.side === 'south' ? UNIT_W : UNIT_D;
          const segLen = (wallExtent - doorW) / 2;
          const ax = w.side === 'north' || w.side === 'south' ? 'x' : 'z';
          const positions: [number, number, number][] = [
            ax === 'x'
              ? [-(UNIT_W / 2) + segLen / 2, wallY, w.pos[2]]
              : [w.pos[0], wallY, -(UNIT_D / 2) + segLen / 2],
            ax === 'x'
              ? [(UNIT_W / 2) - segLen / 2, wallY, w.pos[2]]
              : [w.pos[0], wallY, (UNIT_D / 2) - segLen / 2],
          ];
          const args: [number, number, number] =
            ax === 'x' ? [segLen, wallH, WALL_T] : [WALL_T, wallH, segLen];
          return (
            <group key={i}>
              {positions.map((p, j) => (
                <WallMesh key={j} position={p} args={args} xrayMode={xrayMode} />
              ))}
              <mesh position={[0, 0.02, w.pos[2]]} material={matMullion}>
                <boxGeometry args={ax === 'x' ? [doorW, 0.04, 0.06] : [0.06, 0.04, doorW]} />
              </mesh>
            </group>
          );
        }
        const winW = 1.2;
        const winH = 1.2;
        const isHorizontal = w.side === 'north' || w.side === 'south';
        const wallExtent = isHorizontal ? UNIT_W : UNIT_D;
        const wallT = WALL_T;
        const segLen = (wallExtent - winW) / 2;
        const ax = isHorizontal ? 'x' : 'z';
        const segPositions: [number, number, number][] = isHorizontal
          ? [
              [-(wallExtent / 2) + segLen / 2, wallY, w.pos[2]],
              [(wallExtent / 2) - segLen / 2, wallY, w.pos[2]],
            ]
          : [
              [w.pos[0], wallY, -(wallExtent / 2) + segLen / 2],
              [w.pos[0], wallY, (wallExtent / 2) - segLen / 2],
            ];
        const segArgs: [number, number, number] = isHorizontal
          ? [segLen, wallH, wallT]
          : [wallT, wallH, segLen];
        const lintelArgs: [number, number, number] = isHorizontal
          ? [winW, wallH - winH - 0.2, wallT]
          : [wallT, wallH - winH - 0.2, winW];
        const lintelPos: [number, number, number] = isHorizontal
          ? [0, winH + 0.1 + (wallH - winH - 0.2) / 2, w.pos[2]]
          : [w.pos[0], winH + 0.1 + (wallH - winH - 0.2) / 2, 0];
        const sillArgs: [number, number, number] = isHorizontal
          ? [winW + 0.1, 0.12, wallT]
          : [wallT, 0.12, winW + 0.1];
        const sillPos: [number, number, number] = isHorizontal
          ? [0, 0.5, w.pos[2]]
          : [w.pos[0], 0.5, 0];
        return (
          <group key={i}>
            {segPositions.map((p, j) => (
              <WallMesh key={j} position={p} args={segArgs} xrayMode={xrayMode} />
            ))}
            <WallMesh position={lintelPos} args={lintelArgs} xrayMode={xrayMode} />
            <WallMesh position={sillPos} args={sillArgs} xrayMode={xrayMode} />
            <mesh
              material={matGlass}
              position={isHorizontal ? [0, winH / 2 + 0.1, w.pos[2]] : [w.pos[0], winH / 2 + 0.1, 0]}
            >
              <boxGeometry args={isHorizontal ? [winW * 0.95, winH, 0.04] : [0.04, winH, winW * 0.95]} />
            </mesh>
            <mesh
              material={matMullion}
              position={isHorizontal ? [0, winH / 2 + 0.1, w.pos[2]] : [w.pos[0], winH / 2 + 0.1, 0]}
            >
              <boxGeometry args={[0.05, winH, 0.05]} />
            </mesh>
          </group>
        );
      })}

      <WallMesh position={[0, wallY, 0]} args={[WALL_T, wallH * 0.85, UNIT_D * 0.7]} xrayMode={xrayMode} />

      <UnitBalcony
        side={opposite(facingCore)}
        unitW={UNIT_W}
        unitD={UNIT_D}
        wallH={wallH}
      />

      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.012, 0]}>
        <planeGeometry args={[UNIT_W - 0.1, UNIT_D - 0.1]} />
        <meshStandardMaterial
          color={new THREE.Color('#37393f')}
          roughness={0.92}
          metalness={0.0}
          userData={{ viewerWall: false, viewerFade: true, _baseOpacity: 1 }}
          transparent
          opacity={0}
        />
      </mesh>
    </group>
  );
}

function WallMesh({
  position,
  args,
  xrayMode,
}: {
  position: [number, number, number];
  args: [number, number, number];
  xrayMode?: boolean;
}) {
  const baseOpacity = xrayMode ? 0.10 : 1.0;
  const mat = useMemo(() => {
    const src = xrayMode ? matXrayFacade : matConcrete;
    const m = src.clone();
    m.userData = { viewerWall: true, viewerFade: true, _baseOpacity: baseOpacity };
    m.transparent = true;
    // Initialize at baseOpacity (NOT 0) so the material is visible
    // immediately when created. The transition controller will lerp
    // it when needed (during phase transitions).
    m.opacity = baseOpacity;
    return m;
  }, [xrayMode, baseOpacity]);

  // X-ray wireframe edges on this wall
  const edges = useMemo(() => {
    if (!xrayMode) return null;
    return new THREE.EdgesGeometry(new THREE.BoxGeometry(args[0], args[1], args[2]));
  }, [xrayMode, args[0], args[1], args[2]]);

  return (
    <>
      <mesh position={position} material={mat}>
        <boxGeometry args={args} />
      </mesh>
      {xrayMode && edges && (
        <lineSegments position={position} geometry={edges} material={matXrayWireframe} />
      )}
    </>
  );
}

function opposite(side: 'north' | 'south' | 'east' | 'west') {
  return side === 'north' ? 'south' : side === 'south' ? 'north' : side === 'east' ? 'west' : 'east';
}

/* ------------------------------------------------------------------ */
/* Balcony on the unit (extracted view)                               */
/* ------------------------------------------------------------------ */

function UnitBalcony({
  side,
  unitW,
  unitD,
  wallH,
}: {
  side: 'north' | 'south' | 'east' | 'west';
  unitW: number;
  unitD: number;
  wallH: number;
}) {
  const balW = (side === 'north' || side === 'south' ? unitW : unitD) * 0.6;
  const balDepth = 1.2;
  const railingH = 1.0;
  const offsetDist = (side === 'north' || side === 'south' ? unitD : unitW) / 2 + balDepth / 2;
  const pos: [number, number, number] =
    side === 'north' ? [0, 0, -offsetDist]
    : side === 'south' ? [0, 0, offsetDist]
    : side === 'east' ? [offsetDist, 0, 0]
    : [-offsetDist, 0, 0];

  const isHorizontal = side === 'north' || side === 'south';

  return (
    <group position={pos}>
      <mesh material={matBalconyTile} position={[0, -0.05, 0]}>
        <boxGeometry args={isHorizontal ? [balW, 0.08, balDepth] : [balDepth, 0.08, balW]} />
      </mesh>
      <mesh
        material={matRailing}
        position={
          isHorizontal
            ? [0, railingH / 2, side === 'north' ? -balDepth : balDepth]
            : [side === 'east' ? balDepth : -balDepth, railingH / 2, 0]
        }
      >
        <boxGeometry args={isHorizontal ? [balW, railingH, 0.04] : [0.04, railingH, balW]} />
      </mesh>
      <mesh
        material={matRailing}
        position={
          isHorizontal
            ? [0, railingH + 0.02, side === 'north' ? -balDepth : balDepth]
            : [side === 'east' ? balDepth : -balDepth, railingH + 0.02, 0]
        }
      >
        <boxGeometry args={isHorizontal ? [balW + 0.05, 0.05, 0.06] : [0.06, 0.05, balW + 0.05]} />
      </mesh>
    </group>
  );
}

/* ------------------------------------------------------------------ */
/* Connector line                                                      */
/* ------------------------------------------------------------------ */

function ConnectorLine({ fromX, toX, y }: { fromX: number; toX: number; y: number }) {
  const segs = 12;
  const totalLen = toX - fromX;
  const segLen = totalLen / (segs * 2);
  return (
    <group position={[0, y, 0]}>
      {Array.from({ length: segs }, (_, i) => {
        const t = (i + 0.5) / segs;
        const x = fromX + t * totalLen;
        return (
          <mesh key={i} position={[x, 0, 0]}>
            <boxGeometry args={[segLen, 0.04, 0.04]} />
            <meshBasicMaterial color={new THREE.Color('#3ad7dd')} transparent opacity={0.55} />
          </mesh>
        );
      })}
    </group>
  );
}

/* X-ray interior floor plan — dark slate blue lines at 100% opacity */
function ExtractedFloorPlan() {
  const planY = -0.12;
  const geo = useMemo(() => {
    const verts: number[] = [];
    const push = (x1: number, z1: number, x2: number, z2: number) => {
      verts.push(x1, planY, z1, x2, planY, z2);
    };
    const CORE = 4;
    push(-CORE/2, -CORE/2, CORE/2, -CORE/2);
    push(CORE/2, -CORE/2, CORE/2, CORE/2);
    push(CORE/2, CORE/2, -CORE/2, CORE/2);
    push(-CORE/2, CORE/2, -CORE/2, -CORE/2);
    const UW = 6.5, UD = 5.0;
    const centers = [
      [0.8 + CORE/2 + UW/2, -(0.8 + CORE/2 + UD/2)],
      [-(0.8 + CORE/2 + UW/2), -(0.8 + CORE/2 + UD/2)],
      [-(0.8 + CORE/2 + UW/2), 0.8 + CORE/2 + UD/2],
      [0.8 + CORE/2 + UW/2, 0.8 + CORE/2 + UD/2],
    ];
    for (const [cx, cz] of centers) {
      push(cx-UW/2, cz-UD/2, cx+UW/2, cz-UD/2);
      push(cx+UW/2, cz-UD/2, cx+UW/2, cz+UD/2);
      push(cx+UW/2, cz+UD/2, cx-UW/2, cz+UD/2);
      push(cx-UW/2, cz+UD/2, cx-UW/2, cz-UD/2);
      push(cx, cz-UD/2, cx, cz+UD/2);
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute(verts, 3));
    return g;
  }, []);
  const mat = useMemo(() => new THREE.LineBasicMaterial({
    color: new THREE.Color('#2C3E50'), transparent: true, opacity: 1.0,
  }), []);
  return <lineSegments geometry={geo} material={mat} />;
}
