/**
 * viewer-materials.ts
 *
 * Shared geometries + materials for the 3D building viewer.
 *
 * Design system: light Whimsical/Linear theme.
 * - Scene background: #F6F7F9 (canvas token)
 * - Building facade: warm white / light grey — no dark colours
 * - Windows: indigo-200 glass (#C7D2FE) — no pure black
 * - X-ray: indigo-900 (#312E81) edges, indigo-50 transparent body
 * - Ground: near-white (#F3F4F6) with #E5E7EB grid
 * - NO pure black (#000 / 'black') anywhere
 *
 * Mirrors src/lib/design-tokens.ts SCENE palette.
 */

import * as THREE from 'three';
import { SCENE } from './design-tokens';

/* ------------------------------------------------------------------ */
/* Materials                                                           */
/* ------------------------------------------------------------------ */

/** Concrete facade — warm off-white, architectural light tone. */
export const matConcrete = new THREE.MeshStandardMaterial({
  color: new THREE.Color(SCENE.concreteFacade), // #F3F4F6
  roughness: 0.72,
  metalness: 0.02,
});

/** X-ray facade — very transparent, indigo-50 tint.
 *  Edge lines (EdgesGeometry) carry the silhouette. */
export const matXrayFacade = new THREE.MeshStandardMaterial({
  color: new THREE.Color(SCENE.xrayFacade), // #EEF2FF
  roughness: 0.2,
  metalness: 0.0,
  transparent: true,
  opacity: 0.08,
  side: THREE.DoubleSide,
  depthWrite: false,
});

/** X-ray slab — 30% opacity, indigo-100 tint. */
export const matXraySlab = new THREE.MeshStandardMaterial({
  color: new THREE.Color('#E0E7FF'), // indigo-100
  roughness: 0.5,
  metalness: 0.0,
  transparent: true,
  opacity: 0.30,
  side: THREE.DoubleSide,
  depthWrite: false,
});

/** X-ray wireframe overlay — indigo-900 edges (#312E81), blueprint feel. */
export const matXrayWireframe = new THREE.LineBasicMaterial({
  color: new THREE.Color(SCENE.xrayEdge), // #312E81
  transparent: true,
  opacity: 0.85,
});

/** Slab edge — slightly darker neutral, visible band between floors. */
export const matSlabEdge = new THREE.MeshStandardMaterial({
  color: new THREE.Color(SCENE.slabEdge), // #D1D5DB
  roughness: 0.85,
  metalness: 0.03,
});

/** Soffit / underside of slab — medium grey, reads as a shadow line. */
export const matSoffit = new THREE.MeshStandardMaterial({
  color: new THREE.Color(SCENE.soffit), // #9CA3AF
  roughness: 0.95,
  metalness: 0.0,
});

/** Basement concrete — cooler, slightly darker neutral. */
export const matBasement = new THREE.MeshStandardMaterial({
  color: new THREE.Color(SCENE.basement), // #CBD5E1
  roughness: 0.90,
  metalness: 0.02,
});

/** Glass — indigo-200 (#C7D2FE) at ~60% opacity.
 *  Light, architectural. No pure black or deep cyan. */
export const matGlass = new THREE.MeshStandardMaterial({
  color: new THREE.Color(SCENE.glass), // #C7D2FE
  roughness: 0.10,
  metalness: SCENE.glassMetal,         // 0.25
  envMapIntensity: 0.6,
  transparent: true,
  opacity: 0.60,
});

/** Window mullion / frame — medium neutral, slightly metallic. */
export const matMullion = new THREE.MeshStandardMaterial({
  color: new THREE.Color(SCENE.mullion), // #94A3B8
  roughness: 0.50,
  metalness: 0.60,
});

/** Balcony railing — light neutral. */
export const matRailing = new THREE.MeshStandardMaterial({
  color: new THREE.Color(SCENE.railing), // #94A3B8
  roughness: 0.45,
  metalness: 0.55,
});

/** Balcony tile surface — very light warm grey. */
export const matBalconyTile = new THREE.MeshStandardMaterial({
  color: new THREE.Color(SCENE.balconyTile), // #E5E7EB
  roughness: 0.92,
  metalness: 0.01,
});

/** Parapet — near-white, slightly lighter than facade. */
export const matParapet = new THREE.MeshStandardMaterial({
  color: new THREE.Color(SCENE.parapet), // #F3F4F6
  roughness: 0.82,
  metalness: 0.02,
});

/** Rooftop water tank — slate blue-grey. */
export const matWaterTank = new THREE.MeshStandardMaterial({
  color: new THREE.Color(SCENE.waterTank), // #CBD5E1
  roughness: 0.65,
  metalness: 0.20,
});

/** Rooftop mechanical equipment — medium grey. */
export const matMech = new THREE.MeshStandardMaterial({
  color: new THREE.Color(SCENE.mech), // #9CA3AF
  roughness: 0.70,
  metalness: 0.45,
});

/** Ground / plot surface — very light, near canvas background. */
export const matGround = new THREE.MeshStandardMaterial({
  color: new THREE.Color(SCENE.ground), // #EBEBED
  roughness: 0.98,
  metalness: 0.0,
});

/** Pavement / driveway — slightly darker than ground. */
export const matPavement = new THREE.MeshStandardMaterial({
  color: new THREE.Color(SCENE.pavement), // #F3F4F6
  roughness: 0.90,
  metalness: 0.01,
});

/** Pathway — same as pavement, slightly warmer. */
export const matPathway = new THREE.MeshStandardMaterial({
  color: new THREE.Color(SCENE.pathway), // #E5E7EB
  roughness: 0.94,
  metalness: 0.0,
});

/** Vegetation — soft green (not dark). */
export const matFoliage = new THREE.MeshStandardMaterial({
  color: new THREE.Color(SCENE.foliage), // #86EFAC
  roughness: 0.90,
  metalness: 0.0,
});

/** Tree trunk — neutral grey. */
export const matTrunk = new THREE.MeshStandardMaterial({
  color: new THREE.Color(SCENE.trunk), // #A3A3A3
  roughness: 0.96,
  metalness: 0.0,
});

/** Entrance canopy glass — light indigo tint. */
export const matCanopy = new THREE.MeshStandardMaterial({
  color: new THREE.Color(SCENE.canopy), // #C7D2FE
  roughness: 0.20,
  metalness: 0.3,
  transparent: true,
  opacity: 0.55,
});

/* ------------------------------------------------------------------ */
/* Highlight materials (per-floor selection / hover)                  */
/* ------------------------------------------------------------------ */

/**
 * Selected floor: translucent indigo-500 slab.
 * Clone of concrete so swapping is cheap.
 */
export function makeFacadeHighlight(tint: string, intensity = 0.5) {
  const m = matConcrete.clone();
  m.emissive = new THREE.Color(tint);
  m.emissiveIntensity = intensity;
  m.toneMapped = true;
  return m;
}

/**
 * X-ray compatible highlight — clones matXrayFacade (transparent).
 */
export function makeXrayHighlight(tint: string, intensity = 0.12) {
  const m = matXrayFacade.clone();
  m.emissive = new THREE.Color(tint);
  m.emissiveIntensity = intensity;
  m.toneMapped = true;
  m.opacity = matXrayFacade.opacity;
  m.transparent = true;
  m.depthWrite = false;
  m.side = THREE.DoubleSide;
  return m;
}

/** Accent emissive — indigo-500 for selection beam / outline glow. */
export const matAccentEmissive = new THREE.MeshBasicMaterial({
  color: new THREE.Color(SCENE.accentEmissive), // #6366F1
  transparent: true,
  opacity: 0.85,
});

/* ------------------------------------------------------------------ */
/* Shared geometries                                                   */
/* ------------------------------------------------------------------ */

/** A thin box geometry helper. */
export function box(w: number, h: number, d: number) {
  return new THREE.BoxGeometry(w, h, d);
}

/** A hollow railing segment using flat panel + posts. */
export function makeRailingSegment(length: number, height: number) {
  const group = new THREE.Group();
  // Top rail
  const top = new THREE.Mesh(box(length, 0.04, 0.04), matRailing);
  top.position.y = height - 0.02;
  group.add(top);
  // Mid rail
  const mid = new THREE.Mesh(box(length, 0.03, 0.03), matRailing);
  mid.position.y = height * 0.55;
  group.add(mid);
  // Vertical posts every ~0.6m
  const postCount = Math.max(2, Math.round(length / 0.6));
  const postGeo = box(0.04, height, 0.04);
  for (let i = 0; i <= postCount; i++) {
    const t = i / postCount;
    const post = new THREE.Mesh(postGeo, matRailing);
    post.position.set(-length / 2 + t * length, height / 2, 0);
    group.add(post);
  }
  return group;
}
