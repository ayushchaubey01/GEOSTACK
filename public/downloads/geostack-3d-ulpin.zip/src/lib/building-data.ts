/**
 * Demo data model for the 3D ULPIN / Vertical Property Mapping viewer.
 *
 * The shape of this file is intentionally designed so that real backend
 * data (from a PostGIS / FastAPI service) can later replace the mock
 * values without touching the rendering layer.
 */

export type Vec2 = { x: number; z: number };

export interface UnitFootprint {
  /** Floor-relative origin in meters (x = east, z = north). 0,0 is the center of the floor slab. */
  origin: Vec2;
  /** Footprint size in meters. */
  size: { w: number; d: number };
  /** Door opening position on the central corridor (unit edge index, 0..3). */
  doorEdge: 0 | 1 | 2 | 3;
}

export interface Unit {
  unitId: string;
  floorNumber: number;
  /** e.g. "1102" — display only */
  displayId: string;
  carpetArea: number; // m²
  builtUpArea: number; // m²
  ulpin: string; // 3D ULPIN (vertical, floor, unit)
  footprint: UnitFootprint;
  bedrooms: number;
  bathrooms: number;
  facing: 'East' | 'West' | 'North' | 'South';
  ownerName: string;
  /** True for parking slots in basements. */
  isParking: boolean;
}

export interface Floor {
  floorNumber: number; // 0 = ground, 1 = first, etc.; negative = basement
  /** Display label such as "Ground", "1st", "12th", "Basement 1". */
  label: string;
  height: number; // meters floor-to-floor
  units: Unit[];
  /** Vertical ULPIN for this floor. */
  ulpin: string;
  /** Layout variant 0..2 — controls balcony/facade variation. */
  variant: 0 | 1 | 2;
  /** Total floor area in m². */
  floorArea: number;
  /** True if this floor is below ground (basement / parking / utility). */
  isUnderground: boolean;
  /** Optional use-type tag for basements: 'parking' | 'utility' | 'residential'. */
  usage?: 'parking' | 'utility' | 'residential';
}

export interface BuildingFootprint {
  /** Width (X axis) of the tower slab. */
  width: number;
  /** Depth (Z axis) of the tower slab. */
  depth: number;
  /** Center of the building in world space (used for camera framing). */
  center: Vec2;
}

export interface Building {
  ulpin: string;
  name: string;
  address: string;
  locality: string;
  reraId: string;
  totalFloors: number;
  floors: Floor[];
  footprint: BuildingFootprint;
  /** Plot size — area of land parcel that the building sits on, in m². */
  plotArea: number;
  /** Year of construction (mock). */
  yearBuilt: number;
}

/* ------------------------------------------------------------------ */
/* Mock data generators                                                */
/* ------------------------------------------------------------------ */

const ULPIN_ROOT = '27345091827301'; // 14-digit parcel root (synthetic)

const FACINGS: Unit['facing'][] = ['East', 'West', 'North', 'South'];

const FIRST_NAMES = [
  'Arjun & Priya Iyer',
  'Rohit & Ananya Sharma',
  'Vikram & Meera Nair',
  'Sanjay & Kavya Reddy',
  'Aditya & Shruti Rao',
  'Karthik & Divya Menon',
  'Nikhil & Isha Agarwal',
  'Manish & Pooja Desai',
];

/** Build a single floor with 4 apartment units arranged around a central core. */
function buildFloor(floorNumber: number, _total: number): Floor {
  const isUnderground = floorNumber < 0;
  const label = isUnderground
    ? `Basement ${Math.abs(floorNumber)}`
    : floorNumber === 0
      ? 'Ground'
      : ordinalLabel(floorNumber);

  // 4-unit layout. Each unit occupies one quadrant of the floor slab.
  // Slab is 18m wide × 14m deep, with a 4m × 4m central core (lift + stair).
  const unitW = 6.5; // east-west extent of unit
  const unitD = 5.0; // north-south extent
  const units: Unit[] = [0, 1, 2, 3].map((i) => {
    const displayId = isUnderground
      ? `B${Math.abs(floorNumber)}0${i + 1}`
      : `${floorNumber}0${i + 1}`;
    const unitId = `${displayId}`;
    const ulpin = `${ULPIN_ROOT}-F${floorNumber}-U${displayId}`;
    const origin = unitOrigin(i, unitW, unitD);
    // For basements: 2 parking slots per quadrant (no real "owner")
    const isParking = isUnderground && i < 2;
    const bedrooms = isParking ? 0 : (i % 2 === 0 ? 3 : 2);
    const bathrooms = bedrooms === 3 ? 2 : bedrooms === 2 ? 1 : 0;
    const carpetArea = isParking ? 28.0 : (bedrooms === 3 ? 92.5 : 68.0);
    const builtUpArea = carpetArea * (isParking ? 1.0 : 1.18);
    return {
      unitId,
      floorNumber,
      displayId,
      carpetArea,
      builtUpArea,
      ulpin,
      bedrooms,
      bathrooms,
      facing: FACINGS[i],
      ownerName: isParking ? 'Parking Slot' : FIRST_NAMES[(Math.abs(floorNumber) * 4 + i) % FIRST_NAMES.length],
      isParking,
      footprint: {
        origin,
        size: { w: unitW, d: unitD },
        doorEdge: (i as 0 | 1 | 2 | 3),
      },
    };
  });

  const floorArea = units.reduce((s, u) => s + u.builtUpArea, 0) + 24; // + core
  const variant: 0 | 1 | 2 = (Math.floor(Math.abs(floorNumber) / 3) % 3) as 0 | 1 | 2;

  return {
    floorNumber,
    label,
    height: 3.0,
    units,
    ulpin: `${ULPIN_ROOT}-F${floorNumber}`,
    variant,
    floorArea: Math.round(floorArea * 10) / 10,
    isUnderground,
    usage: isUnderground ? (floorNumber === -1 ? 'parking' : 'utility') : 'residential',
  };
}

function unitOrigin(i: number, w: number, d: number): Vec2 {
  // 0 = NE, 1 = NW, 2 = SW, 3 = SE quadrant
  switch (i) {
    case 0:
      return { x: 0.8 + w / 2, z: -(0.8 + d / 2) };
    case 1:
      return { x: -(0.8 + w / 2), z: -(0.8 + d / 2) };
    case 2:
      return { x: -(0.8 + w / 2), z: 0.8 + d / 2 };
    case 3:
    default:
      return { x: 0.8 + w / 2, z: 0.8 + d / 2 };
  }
}

function ordinalLabel(n: number): string {
  if (n === 1) return '1st';
  if (n === 2) return '2nd';
  if (n === 3) return '3rd';
  return `${n}th`;
}

export function createMockBuilding(): Building {
  // Above-ground floors: 0 (Ground) + 11 numbered floors = 12 total.
  // Below-ground: 2 basements (B1 = parking, B2 = utility).
  const aboveGroundFloors = 12; // ground + 1st..11th
  const basementCount = 2;
  const floors: Floor[] = [];

  // Basements first (floorNumber = -1, -2)
  for (let b = basementCount; b >= 1; b--) {
    floors.push(buildFloor(-b, aboveGroundFloors));
  }
  // Above-ground: 0..N-1
  for (let i = 0; i < aboveGroundFloors; i++) {
    floors.push(buildFloor(i, aboveGroundFloors));
  }

  return {
    ulpin: ULPIN_ROOT,
    name: 'Prestige Indigo Heights',
    address: '5th Cross, Indiranagar 2nd Stage',
    locality: 'Bengaluru — Ward 111',
    reraId: 'PRM/KA/RERA/1251/446/PR/240218/006821',
    totalFloors: aboveGroundFloors + basementCount,
    floors,
    plotArea: 1860,
    yearBuilt: 2022,
    footprint: {
      width: 20,
      depth: 16,
      center: { x: 0, z: 0 },
    },
  };
}

export const MOCK_BUILDING = createMockBuilding();

/* ------------------------------------------------------------------ */
/* Create a Building from a real GeoJSON map feature                  */
/* ------------------------------------------------------------------ */

import type { MapBuildingFeature } from './map-data';

/**
 * Convert a real building feature (from the 2D map) into a Building
 * data object that the 3D viewer can render.
 *
 * Uses the feature's real:
 *  - name
 *  - floor count (derived from height in the source data)
 *  - height
 *  - parent parcel code (as a ULPIN-like root)
 *  - centroid (lat/lng → used in the address string)
 *
 * The flat (unit) data is still mock — the user said they'll provide
 * real flat data later. For now each floor gets 4 mock units.
 */
export function createBuildingFromFeature(feature: MapBuildingFeature): Building {
  const floors = Math.max(1, Math.min(20, feature.f || 3)); // clamp 1..20
  const basementCount = 1; // give each building 1 basement (parking)
  const allFloors: Floor[] = [];

  // 1 basement (parking)
  for (let b = basementCount; b >= 1; b--) {
    allFloors.push(buildFloor(-b, floors));
  }
  // Above-ground floors
  for (let i = 0; i < floors; i++) {
    allFloors.push(buildFloor(i, floors));
  }

  // Use the feature's centroid lat/lng for the address
  const [lng, lat] = feature.ce;
  const latStr = lat.toFixed(5);
  const lngStr = lng.toFixed(5);

  // Use the parent parcel code as the ULPIN root, or fall back to a
  // synthetic code derived from the feature ID.
  const ulpinRoot = feature.pc || `BLR-P-${String(feature.id).padStart(6, '0')}`;

  return {
    ulpin: ulpinRoot,
    name: feature.n || `Building #${feature.id}`,
    address: `${latStr}°N, ${lngStr}°E`,
    locality: 'Bengaluru Pilot AOI',
    reraId: '— (real RERA data pending)',
    totalFloors: floors + basementCount,
    floors: allFloors,
    plotArea: 0, // not available in the GeoJSON
    yearBuilt: 2020, // the height data is from 2020 (3D-GloBFP)
    footprint: {
      width: 20,
      depth: 16,
      center: { x: 0, z: 0 },
    },
  };
}
